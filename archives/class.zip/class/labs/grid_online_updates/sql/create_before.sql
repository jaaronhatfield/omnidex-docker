use sql/simplegrid.sql

; Insure we are starting with the correct "before" image.  The "before" 
; image has an empty $UPDATES node.  In this database, the initial 
; number of rows is a bit different to allow for rows to be inserted.
;
;                                     HOUSEHOLDS        INDIVIDUALS
;
; Normal database                          1,909              5,000
; This database                            1,886              4,940
; This database after sql/updates1.sql     1,905              4,990
; This database after sql/updates2.sql     1,909              5,000

copy dat/before/*.* dat with delete

; Connect to simplegrid
connect simplegrid.xml

; Discard any previous updates
discard updates

; Update the Omnidex indexes 
update indexes


