Grid Online Updates

This lab will start with a modified version of the database that is 
missing some rows in both HOUSEHOLDS and INDIVIDUALS.  Two sets 
of inserts, deletes, and updates will be run.  
                                                                    johndoe@
                           HOUSEHOLDS  INDIVIDUALS  123 MAIN ST    email.com
 Normal database                1,909        5,000            0            0
 
 use sql/create_before.sql      
 use sql/query.sql              1,886        4,940            0            0

 use sql/updates1.sql           
 use sql/query.sql              1,905        4,990           18           50

 use sql/updates2.sql           
 use sql/query.sql              1,909        5,000            0            0

 use sql/compare.sql can be used to compare the final result

