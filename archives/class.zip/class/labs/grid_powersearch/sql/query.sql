
; This query will demonstrate PowerSearch by locating an individual with 
; expanded and flexible search terms.  In these statements, we will locate
; the following individual:
;
;   NAME              MS. LISA D TOMPKINS
;   PHONE             (310) 199-3720
;   EMAIL             ltompkins50@aol.com
;   ADDRESS           1607 5TH ST
;   CITY              SANTA MONICA
;   STATE             CA
;   ZIP               90401
;   COUNTRY           
;
; First, we will locate them using a normal Omnidex SQL statement:

select        NAME,
              PHONE,
              EMAIL,
              ADDRESS,
              CITY,
              STATE,
              ZIP,
              COUNTRY
  from        INDIVIDUALS
  join        HOUSEHOLDS on INDIVIDUALS.HOUSEHOLD = HOUSEHOLDS.HOUSEHOLD
  where       NAME = 'Lisa Tompkins' and
              ADDRESS = '5th St' and
              STATE = 'CA' and
              CITY = 'Santa Monica' and
              ZIP = '90401' and
              EMAIL = 'ltompkins50@aol.com';


; Now we will locate them using the PowerSearch option.  Note that we can 
; locate the individual despite the differences in criteria:
;
;   - Our criteria is "Elizabeth", but we still found "Lisa" because it is a 
;     well-known given-name synonym.
;   - Our criteria is "Fifth Street", but we still found "5th St" because
;     they are well-known postal abbreviation synonyms.
;   - Our criteria is "Santa Minoca", but we still found "Santa Monica" 
;     because of a misspelling search.
;   - Our criteria is "90402", but we still found "90401" because it is 
;     a nearby zipcode.
;   - Our criteria is "ltomkins@aol.com", but we still found 
;     "ltompkins50@aol.com" because of a misspelling search.

set explain text

select        NAME,
              PHONE,
              EMAIL,
              ADDRESS,
              CITY,
              STATE,
              ZIP,
              COUNTRY
  from        INDIVIDUALS
  join        HOUSEHOLDS on INDIVIDUALS.HOUSEHOLD = HOUSEHOLDS.HOUSEHOLD
  where       PHONE > ' ' and
              EMAIL > ' ' and
              NAME = 'Elizabeth Tompkens' and
              ADDRESS = 'Fifth Street' and
              STATE = 'CA' and
              CITY = 'santa minoca' and
              ZIP = '90402' and
              EMAIL = 'ltompkens@aol.com'
  with        powersearch;

explain

