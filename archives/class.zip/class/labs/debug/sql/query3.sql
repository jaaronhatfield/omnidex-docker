set debug all

; The $ABORT table is a fictitous table that will always cause an abort
; when referenced in a SQL statement.  This is done to enable testing 
; of exceptional conditions.

connect simple

select count(*) from $abort;

disconnect


