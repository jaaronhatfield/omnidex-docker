set debug all

connect simple

select count(*) from individuals;

disconnect




