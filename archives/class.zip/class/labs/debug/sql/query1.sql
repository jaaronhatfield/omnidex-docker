set debug on

connect simple

select count(*) from individuals;

disconnect


