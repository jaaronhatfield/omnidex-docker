-- Connect as simple to create tables
create table HOUSEHOLDS
       (HOUSEHOLD               CHAR(12),
        ADDRESS                 CHAR(50),
        CITY                    CHAR(28),
        STATE                   CHAR(2),
        ZIP                     CHAR(5),
        COUNTRY                 CHAR(2),
        constraint              HOUSEHOLDS_HOUSEHOLD_PK
                                primary key (HOUSEHOLD)
                                using index);

create table INDIVIDUALS
       (INDIVIDUAL              CHAR(12),
        HOUSEHOLD               CHAR(12),
        NAME                    CHAR(50),
        GENDER                  CHAR(1),
        BIRTHDATE               DATE,
        PHONE                   CHAR(14),
        EMAIL                   CHAR(60),
        constraint              INDIVIDUALS_INDIVIDUAL_PK
                                primary key (INDIVIDUAL)
                                using index,
        constraint              INDIVIDUALS_HOUSEHOLD_FK
                                foreign key (HOUSEHOLD) 
                                references HOUSEHOLDS(HOUSEHOLD));

commit;

quit;
