connect simple

select count(*) from households cross join individuals with timeout=1;

disconnect

