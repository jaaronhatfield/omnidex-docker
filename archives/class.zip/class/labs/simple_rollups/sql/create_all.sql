use sql/simple.sql

connect simple.xml

update rollups;

update indexes;

disconnect
