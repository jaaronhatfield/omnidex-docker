use sql/simple.sql

connect simple.xml

; Update the Omnidex indexes 
update indexes;

disconnect
