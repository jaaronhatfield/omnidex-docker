create database SIMPLE character set 'ascii' collate 'ascii_bin';

grant all privileges on SIMPLE.* to 'simple' identified by 'simple';
grant file, show databases on *.* to 'simple';
show grants for 'simple';

grant all privileges on SIMPLE.* to 'simple'@'localhost' identified by 'simple';
grant file, show databases on *.* to 'simple'@'localhost';
show grants for 'simple'@'localhost';
