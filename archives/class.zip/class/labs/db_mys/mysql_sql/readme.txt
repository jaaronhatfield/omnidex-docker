
The following commands can be used to create the MySQL version of the 
SIMPLE database:


1. This command will build the MySQL tablespace and user.  This command
   should be run from the 'root' user, or an equivalent user with 
   appropriate privileges.

      mysql --user="root" --password="manager" < create_tablespace.sql
      

2. This command will create the MySQL tables and constraints.  This command
   should be run from the 'simple' user.

      mysql --user="simple" --password="simple" --database="simple" < create_tables.sql


3. This command will insert the data into the newly created tables.  This 
   command should be run from the 'simple' user.

      mysql --user="simple" --password="simple" --database="simple" < insert_data.sql


4. If needed, this command will remove the tablespaces and the user.  It 
   will be necessary to manually delete the data file.  This command should 
   be run from the 'root' user, or an equivalent user with appropriate 
   privileges.

      mysql --user="root" --password="manager" < drop_tablespace.sql



