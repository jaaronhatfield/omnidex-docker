SET storage_engine = INNODB;

create table COUNTRIES
       (COUNTRY                 CHAR(2)            NOT NULL,
        DESCRIPTION             VARCHAR(47)        NULL,
        LATITUDE                DOUBLE             NULL,
        LONGITUDE               DOUBLE             NULL,
        CAPITAL                 VARCHAR(31)        NULL,
        CAPITAL_LAT             DOUBLE             NULL,
        CAPITAL_LONG            DOUBLE             NULL,
        constraint              COUNTRIES_COUNTRY_PK
                                primary key (COUNTRY));

create table STATES
       (STATE                   CHAR(2)            NOT NULL,
        DESCRIPTION             VARCHAR(31)        NULL,
        STATE_CODE              CHAR(2)            NULL,
        REGION                  CHAR(2)            NULL,
        COUNTRY                 CHAR(2)            NULL,
        TAX_RATE                DOUBLE             NULL,
        constraint              STATES_STATE_PK
                                primary key (STATE),
        constraint              STATES_COUNTRY_FK
                                foreign key (COUNTRY) 
                                references COUNTRIES(COUNTRY));

create table GENDERS
       (GENDER                  CHAR(1)            NOT NULL,
        DESCRIPTION             VARCHAR(31)        NULL,
        constraint              GENDERS_GENDER_PK
                                primary key (GENDER));

create table HOUSEHOLDS
       (HOUSEHOLD               CHAR(12),
        ADDRESS                 CHAR(50),
        CITY                    CHAR(28),
        STATE                   CHAR(2),
        ZIP                     CHAR(5),
        COUNTRY                 CHAR(2),
        constraint              HOUSEHOLDS_HOUSEHOLD_PK
                                primary key (HOUSEHOLD),
        constraint              HOUSEHOLDS_STATE_FK
                                foreign key (STATE) 
                                references STATES(STATE),
        constraint              HOUSEHOLDS_COUNTRY_FK
                                foreign key (COUNTRY) 
                                references COUNTRIES(COUNTRY));

create table INDIVIDUALS
       (INDIVIDUAL              CHAR(12),
        HOUSEHOLD               CHAR(12),
        NAME                    CHAR(50),
        GENDER                  CHAR(1),
        BIRTHDATE               DATE,
        PHONE                   CHAR(14),
        EMAIL                   CHAR(60),
        constraint              INDIVIDUALS_INDIVIDUAL_PK
                                primary key (INDIVIDUAL),
        constraint              INDIVIDUALS_HOUSEHOLD_FK
                                foreign key (HOUSEHOLD) 
                                references HOUSEHOLDS(HOUSEHOLD),
        constraint              INDIVIDUALS_GENDER_FK
                                foreign key (GENDER) 
                                references GENDERS(GENDER));

commit;
