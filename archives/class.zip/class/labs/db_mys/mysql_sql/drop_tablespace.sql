drop database if exists SIMPLE;
revoke all privileges, grant option from 'simple';
drop user 'simple';

revoke all privileges, grant option from 'simple'@'localhost';
drop user 'simple'@'localhost';  
