use sql/simplegrid.sql

connect simplegrid.xml

update rollups;

update indexes;

disconnect
