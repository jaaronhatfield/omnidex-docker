; The follow statements will show queries being redirected to a
; rollup table for better optimization;


; Simple count
select        count(*)
  from        INDIVIDUALS;

explain

; Simple count with criteria
select        count(*)
  from        INDIVIDUALS
  where       BIRTHDATE between 'Jan 1, 1980' and 'Dec 31, 2000';

explain

; Simple count distinct
select        count(distinct GENDER)
  from        INDIVIDUALS;

explain

; Simple count distinct with criteria
select        count(distinct GENDER)
  from        INDIVIDUALS
  where       BIRTHDATE between 'Jan 1, 1980' and 'Dec 31, 2000';

explain

; Simple grouped count
select        GENDER,
              count(*)
  from        INDIVIDUALS
  group by    GENDER;

explain

; Simple grouped count with criteria
select        GENDER,
              count(*)
  from        INDIVIDUALS
  where       BIRTHDATE between 'Jan 1, 1980' and 'Dec 31, 2000'
  group by    GENDER;

explain

; Count grouped by joined table
select        GENDERS.DESCRIPTION,
              count(*)
  from        INDIVIDUALS
  join        GENDERS on INDIVIDUALS.GENDER = GENDERS.GENDER
  group by    GENDERS.DESCRIPTION;

explain

; Count grouped by joined table with criteria
select        GENDERS.DESCRIPTION,
              count(*)
  from        INDIVIDUALS
  join        GENDERS on INDIVIDUALS.GENDER = GENDERS.GENDER
  where       BIRTHDATE between 'Jan 1, 1980' and 'Dec 31, 2000'
  group by    GENDERS.DESCRIPTION;

explain

; Simple grouped count with criteria against HOUSEHOLDS
select        STATE, 
              CITY, 
              count(*) 
  from        HOUSEHOLDS
  where       ZIP between '10000' and '11000'
  group by    STATE,
              CITY;
explain

; Simple group by joined table with criteria using two partitioned tables
select        STATE, 
              CITY, 
              count(*) 
  from        HOUSEHOLDS
  join        INDIVIDUALS on HOUSEHOLDS.HOUSEHOLD = INDIVIDUALS.HOUSEHOLD
  where       ZIP between '10000' and '11000' and
              GENDER = 'M'
  group by    STATE,
              CITY;
explain


