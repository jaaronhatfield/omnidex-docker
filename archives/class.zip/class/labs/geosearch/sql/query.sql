; Show all countries within 500 miles of Paris, France

select        DESCRIPTION,
              $distance((select        CAPITAL_LAT, CAPITAL_LONG
                           from        COUNTRIES
                           where       COUNTRY = 'FR'),
                        LATITUDE,
                        LONGITUDE) DISTANCE,
              LATITUDE,
              LONGITUDE
  from        COUNTRIES
  where       $distance((select        CAPITAL_LAT, CAPITAL_LONG
                           from        COUNTRIES
                           where       COUNTRY = 'FR'),
                        LATITUDE,
                        LONGITUDE) < 1000
  order by    DISTANCE;

explain


