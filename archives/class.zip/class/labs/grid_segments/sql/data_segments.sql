connect to simplegrid

; Create a series of data segments, and then reuse them in a final query.
export        (select        every 100 INDIVIDUAL
                 from        INDIVIDUALS)
  to          "segments/do_not_call.dat"
  with        delete;


; Attach a DO_NOT_CALL segment that is maintained by the application
attach data segment            DO_NOT_CALL
 physical                      "segments/do_not_call.dat";

; Create a data segment for the first order
create permanent data segment  ORDER_123
 physical                      "segments/order_123.dat"
 as (select        INDIVIDUALS.INDIVIDUAL
       from        HOUSEHOLDS H
       join        INDIVIDUALS I on H.HOUSEHOLD = I.HOUSEHOLD
       where       ((H.STATE = 'CO' and
                     H.CITY = 'DENVER') or
                    (H.STATE = 'AZ' and
                     H.CITY = 'PHOENIX')) and
                   I.BIRTHDATE > 'January 1, 1980' and
                   I.INDIVIDUAL <> $segment(DO_NOT_CALL))
 with              delete;

; Create a data segment for the second order, excluding the first order.
create permanent data segment  ORDER_124
 physical                      "segments/order_124.dat"
 as (select        INDIVIDUALS.INDIVIDUAL
       from        HOUSEHOLDS H
       join        INDIVIDUALS I on H.HOUSEHOLD = I.HOUSEHOLD
       where       H.STATE in ('CO', 'AZ') and
                   I.BIRTHDATE > 'January 1, 1970' and
                   I.INDIVIDUAL not in ($segment(DO_NOT_CALL),
                                        $segment(ORDER_123)))
 with              delete;

; Create a data segment for the third order, including user-supplied criteria
create permanent data segment  ORDER_125
 physical                      "segments/order_125.dat"
 as (select        INDIVIDUALS.INDIVIDUAL
       from        HOUSEHOLDS H
       join        INDIVIDUALS I on H.HOUSEHOLD = I.HOUSEHOLD
       where       H.ZIP = $segment('segments/order_125_zipcodes.txt') and
                   I.BIRTHDATE > 'January 1, 1970' and
                   I.INDIVIDUAL not in ($segment(DO_NOT_CALL),
                                        $segment(ORDER_123), 
                                        $segment(ORDER_124)))
 with              delete;


disconnect
