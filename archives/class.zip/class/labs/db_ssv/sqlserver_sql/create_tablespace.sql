-- Connect as SA or equivalent

-- Note that the filenames below are in C:/ since that is the only guaranteed
-- location for all Windows machines.  Change these filenames as needed.

USE master
GO

CREATE DATABASE SIMPLE ON
(
  NAME = 'simple_data',
  FILENAME = 'c:/simple_data.dbf',
  SIZE = 10MB,
  MAXSIZE = UNLIMITED,
  FILEGROWTH = 10MB
)
LOG ON
(
  NAME = 'simple_log',
  FILENAME = 'c:/simple_log.dbf',
  SIZE = 10MB,
  MAXSIZE = UNLIMITED,
  FILEGROWTH = 5MB
)
COLLATE Latin1_General_BIN
GO

sp_dboption SIMPLE, "trunc. log on chkpt.", true
GO
sp_dboption SIMPLE, "ANSI null default", true
GO
sp_dboption SIMPLE, "ANSI nulls", true
GO
sp_dboption SIMPLE, "quoted identifier", true
GO

CREATE LOGIN simple with PASSWORD='simple', CHECK_POLICY=off, DEFAULT_DATABASE=SIMPLE
GO

USE SIMPLE
GO

sp_changedbowner simple
GO

QUIT

