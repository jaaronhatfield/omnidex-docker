
The following commands can be used to create the SQL Server version of the 
SIMPLE database:


1. This command will build the SQL Server tablespace and user.  It can be changed
   as needed to place the data file in the desired location. This command
   should be run from the 'system' user, or an equivalent user with 
   appropriate privileges.

      osql -Usa -Pmanager -isqlserver_sql/create_tablespace.sql


2. This command will create the SQL Server tables and constraints.  This command
   should be run from the 'simple' user.

      osql simple/simple -isqlserver_sql/create_tables.sql


3. This command will insert the data into the newly created tables.  This 
   command should be run from the 'simple' user.

      osql simple/simple -isqlserver_sql/insert_data.sql


4. If needed, this command will remove the tablespaces and the user.  It 
   will be necessary to manually delete the data file.  This command should 
   be run from the 'system' user, or an equivalent user with appropriate 
   privileges.

      osql simple/simple -isqlserver_sql/drop_tablespace.sql



