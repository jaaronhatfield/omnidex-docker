-- Connect as simple to create tables
create table COUNTRIES
       (COUNTRY                 CHAR(2),
        DESCRIPTION             VARCHAR(47),
        LATITUDE                FLOAT(4),
        LONGITUDE               FLOAT(4),
        CAPITAL                 VARCHAR(31),
        CAPITAL_LAT             FLOAT(4),
        CAPITAL_LONG            FLOAT(4),
        constraint              COUNTRIES_COUNTRY_PK
                                primary key (COUNTRY))
go

create table STATES
       (STATE                   CHAR(2),
        DESCRIPTION             VARCHAR(31),
        STATE_CODE              CHAR(2),
        REGION                  CHAR(2),
        COUNTRY                 CHAR(2),
        TAX_RATE                FLOAT(4),
        constraint              STATES_STATE_PK
                                primary key (STATE),
        constraint              STATES_COUNTRY_FK
                                foreign key (COUNTRY) 
                                references COUNTRIES(COUNTRY))
go

create table GENDERS
       (GENDER                  CHAR(1),
        DESCRIPTION             VARCHAR(31),
        constraint              GENDERS_GENDER_PK
                                primary key (GENDER))
go

create table HOUSEHOLDS
       (HOUSEHOLD               CHAR(12),
        ADDRESS                 CHAR(50),
        CITY                    CHAR(28),
        STATE                   CHAR(2),
        ZIP                     CHAR(5),
        COUNTRY                 CHAR(2),
        constraint              HOUSEHOLDS_HOUSEHOLD_PK
                                primary key (HOUSEHOLD),
        constraint              HOUSEHOLDS_STATE_FK
                                foreign key (STATE) 
                                references STATES(STATE),
        constraint              HOUSEHOLDS_COUNTRY_FK
                                foreign key (COUNTRY) 
                                references COUNTRIES(COUNTRY))
go

create table INDIVIDUALS
       (INDIVIDUAL              CHAR(12),
        HOUSEHOLD               CHAR(12),
        NAME                    CHAR(50),
        GENDER                  CHAR(1),
        BIRTHDATE               SMALLDATETIME,
        PHONE                   CHAR(14),
        EMAIL                   CHAR(60),
        constraint              INDIVIDUALS_INDIVIDUAL_PK
                                primary key (INDIVIDUAL),
        constraint              INDIVIDUALS_HOUSEHOLD_FK
                                foreign key (HOUSEHOLD) 
                                references HOUSEHOLDS(HOUSEHOLD),
        constraint              INDIVIDUALS_GENDER_FK
                                foreign key (GENDER) 
                                references GENDERS(GENDER))
go
