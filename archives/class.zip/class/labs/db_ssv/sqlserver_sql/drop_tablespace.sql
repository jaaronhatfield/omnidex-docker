-- Connect as system/manager

drop database SIMPLE 
go

USE master
go

sp_droplogin simple
go


