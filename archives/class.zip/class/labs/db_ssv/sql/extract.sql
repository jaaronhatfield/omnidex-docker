extract       DDL
  for         SQLSERVER
  to          "simple.sql"
  with        VERSION="9"
              FILEDSN="dat/simple.dsn"
              USER="simple"
              PASSWORD="simple"
              DATABASE="simple"
              INDEX_DIRECTORY="idx"
