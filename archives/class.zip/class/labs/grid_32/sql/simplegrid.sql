create environment    
 max_threads          32
 node                 "NODE01" partitioned
 node                 "NODE02" partitioned
 node                 "NODE03" partitioned
 node                 "NODE04" partitioned
 node                 "NODE05" partitioned
 node                 "NODE06" partitioned
 node                 "NODE07" partitioned
 node                 "NODE08" partitioned
 node                 "NODE09" partitioned
 node                 "NODE10" partitioned
 node                 "NODE11" partitioned
 node                 "NODE12" partitioned
 node                 "NODE13" partitioned
 node                 "NODE14" partitioned
 node                 "NODE15" partitioned
 node                 "NODE16" partitioned
 node                 "NODE17" partitioned
 node                 "NODE18" partitioned
 node                 "NODE19" partitioned
 node                 "NODE20" partitioned
 node                 "NODE21" partitioned
 node                 "NODE22" partitioned
 node                 "NODE23" partitioned
 node                 "NODE24" partitioned
 node                 "NODE25" partitioned
 node                 "NODE26" partitioned
 node                 "NODE27" partitioned
 node                 "NODE28" partitioned
 node                 "NODE29" partitioned
 node                 "NODE30" partitioned
 node                 "NODE31" partitioned
 node                 "NODE32" partitioned
 in                   "simplegrid.xml"
 with                 delete;


create database       "SIMPLE"
 controller
  index_directory     "idx"
 node "NODE01"        
  type                FILE
  index_directory     "idx/NODE01"
 node "NODE02"        
  type                FILE
  index_directory     "idx/NODE02"
 node "NODE03"        
  type                FILE
  index_directory     "idx/NODE03"
 node "NODE04"        
  type                FILE
  index_directory     "idx/NODE04"
 node "NODE05"        
  type                FILE
  index_directory     "idx/NODE05"
 node "NODE06"        
  type                FILE
  index_directory     "idx/NODE06"
 node "NODE07"        
  type                FILE
  index_directory     "idx/NODE07"
 node "NODE08"        
  type                FILE
  index_directory     "idx/NODE08"
 node "NODE09"        
  type                FILE
  index_directory     "idx/NODE09"
 node "NODE10"        
  type                FILE
  index_directory     "idx/NODE10"
 node "NODE11"        
  type                FILE
  index_directory     "idx/NODE11"
 node "NODE12"        
  type                FILE
  index_directory     "idx/NODE12"
 node "NODE13"        
  type                FILE
  index_directory     "idx/NODE13"
 node "NODE14"        
  type                FILE
  index_directory     "idx/NODE14"
 node "NODE15"        
  type                FILE
  index_directory     "idx/NODE15"
 node "NODE16"        
  type                FILE
  index_directory     "idx/NODE16"
 node "NODE17"        
  type                FILE
  index_directory     "idx/NODE17"
 node "NODE18"        
  type                FILE
  index_directory     "idx/NODE18"
 node "NODE19"        
  type                FILE
  index_directory     "idx/NODE19"
 node "NODE20"        
  type                FILE
  index_directory     "idx/NODE20"
 node "NODE21"        
  type                FILE
  index_directory     "idx/NODE21"
 node "NODE22"        
  type                FILE
  index_directory     "idx/NODE22"
 node "NODE23"        
  type                FILE
  index_directory     "idx/NODE23"
 node "NODE24"        
  type                FILE
  index_directory     "idx/NODE24"
 node "NODE25"        
  type                FILE
  index_directory     "idx/NODE25"
 node "NODE26"        
  type                FILE
  index_directory     "idx/NODE26"
 node "NODE27"        
  type                FILE
  index_directory     "idx/NODE27"
 node "NODE28"        
  type                FILE
  index_directory     "idx/NODE28"
 node "NODE29"        
  type                FILE
  index_directory     "idx/NODE29"
 node "NODE30"        
  type                FILE
  index_directory     "idx/NODE30"
 node "NODE31"        
  type                FILE
  index_directory     "idx/NODE31"
 node "NODE32"        
  type                FILE
  index_directory     "idx/NODE32"
 in                   "simplegrid.xml";


create table          "COUNTRIES"
 physical             "dat/cnt.dat"
 (
  "COUNTRY"           CHARACTER(2)      omnidex,
  "DESCRIPTION"       STRING(47)        quicktext,
  "LATITUDE"          FLOAT             omnidex      usage "LATITUDE",
  "LONGITUDE"         FLOAT             omnidex      usage "LONGITUDE",
  "CAPITAL"           STRING(31)        quicktext,
  "CAPITAL_LAT"       FLOAT             omnidex      usage "LATITUDE",
  "CAPITAL_LONG"      FLOAT             omnidex      usage "LONGITUDE",
  constraint COUNTRIES_COUNTRY_PK primary ("COUNTRY")
 )
 in                   "simplegrid.xml";


create table          "STATES"
 physical             "dat/sta.dat"
 (
  "STATE"             CHARACTER(2)      omnidex,
  "DESCRIPTION"       STRING(31)        quicktext,
  "STATE_CODE"        CHARACTER(2)      omnidex,
  "REGION"            CHARACTER(2)      omnidex,
  "COUNTRY"           CHARACTER(2)      omnidex,
  "TAX_RATE"          FLOAT             omnidex,
  constraint STATES_STATE_PK primary ("STATE"),
  constraint STATES_COUNTRY_FK foreign ("COUNTRY") references "COUNTRIES"
 )
 in                   "simplegrid.xml";


create table          "GENDERS"
 physical             "dat/gdr.dat"
 (
  "GENDER"            CHARACTER(1)      omnidex,
  "DESCRIPTION"       STRING(31)        quicktext,
  constraint GENDERS_GENDER_PK primary ("GENDER")
 )
 in                   "simplegrid.xml";


create table          "HOUSEHOLDS"
 node "NODE01"        
  physical            "dat/households_AK.dat,
                       dat/households_HI.dat,
                       dat/households_OR.dat,
                       dat/households_WA.dat"
  partition_by        "STATE in ('AK','HI','OR','WA')"
 node "NODE02"        
  physical            "dat/households_CA_1.dat"
  partition_by        "STATE in ('CA')"
 node "NODE03"        
  physical            "dat/households_CA_2.dat"
  partition_by        "STATE in ('CA')"
 node "NODE04"        
  physical            "dat/households_CA_3.dat"
  partition_by        "STATE in ('CA')"
 node "NODE05"        
  physical            "dat/households_CA_4.dat"
  partition_by        "STATE in ('CA')"
 node "NODE06"        
  physical            "dat/households_AZ.dat"
  partition_by        "STATE in ('AZ')"
 node "NODE07"        
  physical            "dat/households_NV.dat,
                       dat/households_UT.dat"
  partition_by        "STATE in ('NV','UT')"
 node "NODE08"        
  physical            "dat/households_ID.dat,
                       dat/households_MT.dat,
                       dat/households_ND.dat,
                       dat/households_SD.dat,
                       dat/households_WY.dat"
  partition_by        "STATE in ('ID','MT','ND','SD','WY')"
 node "NODE09"        
  physical            "dat/households_CO.dat"
  partition_by        "STATE in ('CO')"
 node "NODE10"        
  physical            "dat/households_KS.dat,
                       dat/households_NE.dat,
                       dat/households_NM.dat,
                       dat/households_OK.dat"
  partition_by        "STATE in ('KS','NE','NM','OK')"
 node "NODE11"        
  physical            "dat/households_TX.dat"
  partition_by        "STATE in ('TX')"
 node "NODE12"        
  physical            "dat/households_MN.dat,
                       dat/households_WI.dat"
  partition_by        "STATE in ('MN','WI')"
 node "NODE13"        
  physical            "dat/households_IA.dat,
                       dat/households_MO.dat"
  partition_by        "STATE in ('IA','MO')"
 node "NODE14"        
  physical            "dat/households_IL.dat"
  partition_by        "STATE in ('IL')"
 node "NODE15"        
  physical            "dat/households_AR.dat,
                       dat/households_LA.dat,
                       dat/households_MS.dat"
  partition_by        "STATE in ('AR','LA','MS')"
 node "NODE16"        
  physical            "dat/households_AL.dat"
  partition_by        "STATE in ('AL')"
 node "NODE17"        
  physical            "dat/households_KY.dat,
                       dat/households_TN.dat"
  partition_by        "STATE in ('KY','TN')"
 node "NODE18"        
  physical            "dat/households_IN.dat"
  partition_by        "STATE in ('IN')"
 node "NODE19"        
  physical            "dat/households_OH.dat"
  partition_by        "STATE in ('OH')"
 node "NODE20"        
  physical            "dat/households_MI.dat"
  partition_by        "STATE in ('MI')"
 node "NODE21"        
  physical            "dat/households_FL_1.dat"
  partition_by        "STATE in ('FL')"
 node "NODE22"        
  physical            "dat/households_FL_2.dat"
  partition_by        "STATE in ('FL')"
 node "NODE23"        
  physical            "dat/households_GA.dat"
  partition_by        "STATE in ('GA')"
 node "NODE24"        
  physical            "dat/households_NC.dat,
                       dat/households_SC.dat"
  partition_by        "STATE in ('NC','SC')"
 node "NODE25"        
  physical            "dat/households_VA.dat,
                       dat/households_WV.dat"
  partition_by        "STATE in ('VA','WV')"
 node "NODE26"        
  physical            "dat/households_DC.dat,
                       dat/households_DE.dat,
                       dat/households_MD.dat"
  partition_by        "STATE in ('DC','DE','MD')"
 node "NODE27"        
  physical            "dat/households_NJ.dat"
  partition_by        "STATE in ('NJ')"
 node "NODE28"        
  physical            "dat/households_PA.dat"
  partition_by        "STATE in ('PA')"
 node "NODE29"        
  physical            "dat/households_NY.dat"
  partition_by        "STATE in ('NY')"
 node "NODE30"        
  physical            "dat/households_CT.dat,
                       dat/households_RI.dat"
  partition_by        "STATE in ('CT','RI')"
 node "NODE31"        
  physical            "dat/households_MA.dat,
                       dat/households_NH.dat,
                       dat/households_VT.dat,
                       dat/households_ME.dat"
  partition_by        "STATE in ('MA','NH','VT','ME')"
 node "NODE32"        
  physical            "dat/households_PR.dat"
  partition_by        "STATE in ('PR')"
 (
  "HOUSEHOLD"         CHARACTER(12)     omnidex,
  "ADDRESS"           CHARACTER(50)     quicktext,
  "CITY"              CHARACTER(28)     quicktext,
  "STATE"             CHARACTER(2)      omnidex,
  "ZIP"               CHARACTER(5)      omnidex,
  "COUNTRY"           CHARACTER(2)      omnidex,
  constraint HOUSEHOLDS_HOUSEHOLD_PK primary ("HOUSEHOLD"),
  constraint HOUSEHOLDS_STATE_FK foreign ("STATE") references "STATES",
  constraint HOUSEHOLDS_COUNTRY_FK foreign ("COUNTRY") references "COUNTRIES"
 )
 in                   "simplegrid.xml";


create table          "INDIVIDUALS"
 node "NODE01"        
  physical            "dat/individuals_AK.dat,
                       dat/individuals_HI.dat,
                       dat/individuals_OR.dat,
                       dat/individuals_WA.dat"
  partition_by        "INDIVIDUALS.HOUSEHOLD = HOUSEHOLDS.HOUSEHOLD"
 node "NODE02"        
  physical            "dat/individuals_CA_1.dat"
  partition_by        "INDIVIDUALS.HOUSEHOLD = HOUSEHOLDS.HOUSEHOLD"
 node "NODE03"        
  physical            "dat/individuals_CA_2.dat"
  partition_by        "INDIVIDUALS.HOUSEHOLD = HOUSEHOLDS.HOUSEHOLD"
 node "NODE04"        
  physical            "dat/individuals_CA_3.dat"
  partition_by        "INDIVIDUALS.HOUSEHOLD = HOUSEHOLDS.HOUSEHOLD"
 node "NODE05"        
  physical            "dat/individuals_CA_4.dat"
  partition_by        "INDIVIDUALS.HOUSEHOLD = HOUSEHOLDS.HOUSEHOLD"
 node "NODE06"        
  physical            "dat/individuals_AZ.dat"
  partition_by        "INDIVIDUALS.HOUSEHOLD = HOUSEHOLDS.HOUSEHOLD"
 node "NODE07"        
  physical            "dat/individuals_NV.dat,
                       dat/individuals_UT.dat"
  partition_by        "INDIVIDUALS.HOUSEHOLD = HOUSEHOLDS.HOUSEHOLD"
 node "NODE08"        
  physical            "dat/individuals_ID.dat,
                       dat/individuals_MT.dat,
                       dat/individuals_ND.dat,
                       dat/individuals_SD.dat,
                       dat/individuals_WY.dat"
  partition_by        "INDIVIDUALS.HOUSEHOLD = HOUSEHOLDS.HOUSEHOLD"
 node "NODE09"        
  physical            "dat/individuals_CO.dat"
  partition_by        "INDIVIDUALS.HOUSEHOLD = HOUSEHOLDS.HOUSEHOLD"
 node "NODE10"        
  physical            "dat/individuals_KS.dat,
                       dat/individuals_NE.dat,
                       dat/individuals_NM.dat,
                       dat/individuals_OK.dat"
  partition_by        "INDIVIDUALS.HOUSEHOLD = HOUSEHOLDS.HOUSEHOLD"
 node "NODE11"        
  physical            "dat/individuals_TX.dat"
  partition_by        "INDIVIDUALS.HOUSEHOLD = HOUSEHOLDS.HOUSEHOLD"
 node "NODE12"        
  physical            "dat/individuals_MN.dat,
                       dat/individuals_WI.dat"
  partition_by        "INDIVIDUALS.HOUSEHOLD = HOUSEHOLDS.HOUSEHOLD"
 node "NODE13"        
  physical            "dat/individuals_IA.dat,
                       dat/individuals_MO.dat"
  partition_by        "INDIVIDUALS.HOUSEHOLD = HOUSEHOLDS.HOUSEHOLD"
 node "NODE14"        
  physical            "dat/individuals_IL.dat"
  partition_by        "INDIVIDUALS.HOUSEHOLD = HOUSEHOLDS.HOUSEHOLD"
 node "NODE15"        
  physical            "dat/individuals_AR.dat,
                       dat/individuals_LA.dat,
                       dat/individuals_MS.dat"
  partition_by        "INDIVIDUALS.HOUSEHOLD = HOUSEHOLDS.HOUSEHOLD"
 node "NODE16"        
  physical            "dat/individuals_AL.dat"
  partition_by        "INDIVIDUALS.HOUSEHOLD = HOUSEHOLDS.HOUSEHOLD"
 node "NODE17"        
  physical            "dat/individuals_KY.dat,
                       dat/individuals_TN.dat"
  partition_by        "INDIVIDUALS.HOUSEHOLD = HOUSEHOLDS.HOUSEHOLD"
 node "NODE18"        
  physical            "dat/individuals_IN.dat"
  partition_by        "INDIVIDUALS.HOUSEHOLD = HOUSEHOLDS.HOUSEHOLD"
 node "NODE19"        
  physical            "dat/individuals_OH.dat"
  partition_by        "INDIVIDUALS.HOUSEHOLD = HOUSEHOLDS.HOUSEHOLD"
 node "NODE20"        
  physical            "dat/individuals_MI.dat"
  partition_by        "INDIVIDUALS.HOUSEHOLD = HOUSEHOLDS.HOUSEHOLD"
 node "NODE21"        
  physical            "dat/individuals_FL_1.dat"
  partition_by        "INDIVIDUALS.HOUSEHOLD = HOUSEHOLDS.HOUSEHOLD"
 node "NODE22"        
  physical            "dat/individuals_FL_2.dat"
  partition_by        "INDIVIDUALS.HOUSEHOLD = HOUSEHOLDS.HOUSEHOLD"
 node "NODE23"        
  physical            "dat/individuals_GA.dat"
  partition_by        "INDIVIDUALS.HOUSEHOLD = HOUSEHOLDS.HOUSEHOLD"
 node "NODE24"        
  physical            "dat/individuals_NC.dat,
                       dat/individuals_SC.dat"
  partition_by        "INDIVIDUALS.HOUSEHOLD = HOUSEHOLDS.HOUSEHOLD"
 node "NODE25"        
  physical            "dat/individuals_VA.dat,
                       dat/individuals_WV.dat"
  partition_by        "INDIVIDUALS.HOUSEHOLD = HOUSEHOLDS.HOUSEHOLD"
 node "NODE26"        
  physical            "dat/individuals_DC.dat,
                       dat/individuals_DE.dat,
                       dat/individuals_MD.dat"
  partition_by        "INDIVIDUALS.HOUSEHOLD = HOUSEHOLDS.HOUSEHOLD"
 node "NODE27"        
  physical            "dat/individuals_NJ.dat"
  partition_by        "INDIVIDUALS.HOUSEHOLD = HOUSEHOLDS.HOUSEHOLD"
 node "NODE28"        
  physical            "dat/individuals_PA.dat"
  partition_by        "INDIVIDUALS.HOUSEHOLD = HOUSEHOLDS.HOUSEHOLD"
 node "NODE29"        
  physical            "dat/individuals_NY.dat"
  partition_by        "INDIVIDUALS.HOUSEHOLD = HOUSEHOLDS.HOUSEHOLD"
 node "NODE30"        
  physical            "dat/individuals_CT.dat,
                       dat/individuals_RI.dat"
  partition_by        "INDIVIDUALS.HOUSEHOLD = HOUSEHOLDS.HOUSEHOLD"
 node "NODE31"        
  physical            "dat/individuals_MA.dat,
                       dat/individuals_NH.dat,
                       dat/individuals_VT.dat,
                       dat/individuals_ME.dat"
  partition_by        "INDIVIDUALS.HOUSEHOLD = HOUSEHOLDS.HOUSEHOLD"
 node "NODE32"        
  physical            "dat/individuals_PR.dat"
  partition_by        "INDIVIDUALS.HOUSEHOLD = HOUSEHOLDS.HOUSEHOLD"
 (
  "INDIVIDUAL"        CHARACTER(12)     omnidex,
  "HOUSEHOLD"         CHARACTER(12)     omnidex,
  "NAME"              CHARACTER(50)     quicktext,
  "GENDER"            CHARACTER(1)      omnidex bitmap,
  "BIRTHDATE"         ANSI DATE         omnidex,
  "PHONE"             CHARACTER(14)     omnidex,
  "EMAIL"             CHARACTER(60)     quicktext,
  constraint INDIVIDUALS_INDIVIDUAL_PK primary ("INDIVIDUAL"),
  constraint INDIVIDUALS_HOUSEHOLD_FK foreign ("HOUSEHOLD") references "HOUSEHOLDS",
  constraint INDIVIDUALS_GENDER_FK foreign ("GENDER") references "GENDERS",
 )
 in                   "simplegrid.xml";
