; Prejoined tables allow queries to qualify parents, grandparents, etc based 
; on criteria in a child table.

select        distinct HOUSEHOLDS.HOUSEHOLD,
              HOUSEHOLDS.ADDRESS,
              HOUSEHOLDS.CITY,
              HOUSEHOLDS.STATE,
              HOUSEHOLDS.ZIP
  from        HOUSEHOLDS
  join        INDIVIDUALS on INDIVIDUALS.HOUSEHOLD = HOUSEHOLDS.HOUSEHOLD
  where       INDIVIDUALS.GENDER = 'M' and
              INDIVIDUALS.BIRTHDATE between 'Jan 1, 1980' and 'Mar 31, 1980';

explain

; Prejoined tables also allow queries to qualify child tables based on 
; criteria in a sibling table.

select        distinct HOUSEHOLDS.HOUSEHOLD,
              HOUSEHOLDS.ADDRESS,
              HOUSEHOLDS.CITY,
              HOUSEHOLDS.STATE,
              HOUSEHOLDS.ZIP
  from        HOUSEHOLDS
  join        INDIVIDUALS on INDIVIDUALS.HOUSEHOLD = HOUSEHOLDS.HOUSEHOLD
  join        COUNTRIES on HOUSEHOLDS.COUNTRY = COUNTRIES.COUNTRY
  join        STATES on STATES.COUNTRY = COUNTRIES.COUNTRY
  where       INDIVIDUALS.GENDER = 'M' and
              INDIVIDUALS.BIRTHDATE between 'Jan 1, 1980' and 'Mar 31, 1980' and
              STATES.TAX_RATE > 3;

explain

