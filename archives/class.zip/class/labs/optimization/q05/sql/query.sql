; Optimize a query against a single table with grouped counts

set timer on

select        REGION,
              count(*)
  from        STATES
  group by    REGION;

explain
