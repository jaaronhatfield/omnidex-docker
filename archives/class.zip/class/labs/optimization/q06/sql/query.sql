; Optimize a query against a single table with grouped aggregations

set timer on

select        REGION,
              sum(TAX_RATE),
              avg(TAX_RATE),
              count(*)
  from        STATES
  group by    REGION;

explain

