; Optimize a query against many tables requesting a grouped distinct 
; count against a non-primary key in the middle of a table hierarchy

set           timer on

select        count(distinct HOUSEHOLDS.ZIP)
  from        STATES 
  join        HOUSEHOLDS on STATES.STATE = HOUSEHOLDS.STATE
  join        INDIVIDUALS on HOUSEHOLDS.HOUSEHOLD = INDIVIDUALS.HOUSEHOLD
  where       STATES.TAX_RATE > 3.0 and
              (INDIVIDUALS.GENDER = 'M' or
               INDIVIDUALS.NAME = 'William');

explain

