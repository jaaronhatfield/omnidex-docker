; Optimize a query against a multiple tables with multiple criteria

set timer on

select        count(*)
  from        INDIVIDUALS
  join        HOUSEHOLDS on INDIVIDUALS.HOUSEHOLD = HOUSEHOLDS.HOUSEHOLD
  join        STATES on HOUSEHOLDS.STATE = STATES.STATE
  join        COUNTRIES on STATES.COUNTRY = COUNTRIES.COUNTRY
  join        GENDERS on INDIVIDUALS.GENDER = GENDERS.GENDER
  where       COUNTRIES.DESCRIPTION = 'United States' and
              STATES.TAX_RATE >= 3.0 and
              HOUSEHOLDS.CITY = 'Denver' and
              INDIVIDUALS.NAME = 'Brown' and
              GENDERS.DESCRIPTION = 'Male';

explain


; Optimize the same query written to use subqueries
select        count(*)
  from        INDIVIDUALS
  where       HOUSEHOLD in
              (select        HOUSEHOLD
                 from        HOUSEHOLDS
                 where       CITY = 'Denver' and
                             STATE in
                             (select        STATE
                                from        STATES
                                where       TAX_RATE >= 3.0 and
                                            COUNTRY in
                                            (select        COUNTRY
                                               from        COUNTRIES
                                               where       DESCRIPTION =
                                                           'United States')))
              and
              GENDER in
              (select        GENDER
                 from        GENDERS
                 where       DESCRIPTION = 'Male') and
              NAME = 'Brown';

explain
