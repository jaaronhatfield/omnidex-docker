; Optimize a query against a single table with subqueries as criteria

set           timer on

select        count(*)
  from        INDIVIDUALS
  where       INDIVIDUAL in
              (select        INDIVIDUAL
                 from        INDIVIDUALS
                 where       GENDER = 'M') and
              INDIVIDUAL in
              (select        INDIVIDUAL
                 from        INDIVIDUALS
                 where       NAME = 'William');

explain

