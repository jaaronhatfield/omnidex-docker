;Optimize a query against a single table with multiple criteria

set timer on

select        count(*)
  from        INDIVIDUALS
  where       NAME = 'William' and
              BIRTHDATE >= 'Jan 1, 1980';

explain
