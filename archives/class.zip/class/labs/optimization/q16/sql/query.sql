; Optimize a query against a multiple tables requesting a distinct count 
; against the primary key.

set           timer on

select        count(distinct HOUSEHOLDS.HOUSEHOLD)
  from        HOUSEHOLDS
  join        INDIVIDUALS on HOUSEHOLDS.HOUSEHOLD = INDIVIDUALS.HOUSEHOLD
  where       HOUSEHOLDS.STATE = 'CA' and
              (INDIVIDUALS.GENDER = 'M' or
               INDIVIDUALS.NAME = 'William');

explain

