create environment    
 in                   "simple.xml"
 with                 delete;


create database       "SIMPLE"
 type                 FILE
 index_directory      "idx"
 in                   "simple.xml";


create table          "COUNTRIES"
 physical             "../dat/cnt.dat"
 (
  "COUNTRY"           CHARACTER(2),               
  "DESCRIPTION"       STRING(47),                
  "LATITUDE"          FLOAT                          usage "LATITUDE",
  "LONGITUDE"         FLOAT                          usage "LONGITUDE",
  "CAPITAL"           STRING(31),               
  "CAPITAL_LAT"       FLOAT                          usage "LATITUDE",
  "CAPITAL_LONG"      FLOAT                          usage "LONGITUDE",
  constraint COUNTRIES_COUNTRY_PK primary ("COUNTRY")
 )
 in                   "simple.xml";


create table          "STATES"
 physical             "../dat/sta.dat"
 (
  "STATE"             CHARACTER(2),                
  "DESCRIPTION"       STRING(31),                 
  "STATE_CODE"        CHARACTER(2),                
  "REGION"            CHARACTER(2),                
  "COUNTRY"           CHARACTER(2),                
  "TAX_RATE"          FLOAT,                       
  constraint STATES_STATE_PK primary ("STATE"),
  constraint STATES_COUNTRY_FK foreign ("COUNTRY") references "COUNTRIES"
 )
 in                   "simple.xml";


create table          "GENDERS"
 physical             "../dat/gdr.dat"
 (
  "GENDER"            CHARACTER(1),                
  "DESCRIPTION"       STRING(31),                  
  constraint GENDERS_GENDER_PK primary ("GENDER")
 )
 in                   "simple.xml";


create table          "HOUSEHOLDS"
 physical             "../dat/households*.dat"
 (
  "HOUSEHOLD"         CHARACTER(12)     omnidex,               
  "ADDRESS"           CHARACTER(50),               
  "CITY"              CHARACTER(28),               
  "STATE"             CHARACTER(2)      omnidex,                
  "ZIP"               CHARACTER(5),                
  "COUNTRY"           CHARACTER(2),                
  constraint HSHD_HOUSEHOLD_PK primary ("HOUSEHOLD"),
  constraint HSHD_STATE_FK foreign ("STATE") references "STATES",
  constraint HSHD_COUNTRY_FK foreign ("COUNTRY") references "COUNTRIES"
 )
 in                   "simple.xml";


create table          "INDIVIDUALS"
 physical             "../dat/individuals*.dat"
 (
  "INDIVIDUAL"        CHARACTER(12),               
  "HOUSEHOLD"         CHARACTER(12)     omnidex,               
  "NAME"              CHARACTER(50)     quicktext,                
  "GENDER"            CHARACTER(1)      omnidex,                    
  "BIRTHDATE"         ANSI DATE,                
  "PHONE"             CHARACTER(14),               
  "EMAIL"             CHARACTER(60),                  
  constraint IND_INDIVIDUAL_PK primary ("INDIVIDUAL"),
  constraint IND_HOUSEHOLD_FK foreign ("HOUSEHOLD") references "HOUSEHOLDS" prejoin,
  constraint IND_GENDER_FK foreign ("GENDER") references "GENDERS",
 )
 in                   "simple.xml";
