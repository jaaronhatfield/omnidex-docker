; Optimize a query against a single table obtaining a distinct count 
; against the primary key

set           timer on

select        count(distinct INDIVIDUAL)
  from        INDIVIDUALS
  where       GENDER = 'M' or
              NAME = 'William';

explain
