; Optimize a query that joins to subqueries

set timer on

select        count(*)
  from        INDIVIDUALS
  join        (select        HOUSEHOLD
                 from        HOUSEHOLDS
                 join        STATES on HOUSEHOLDS.STATE = STATES.STATE
                 join        COUNTRIES on STATES.COUNTRY = COUNTRIES.COUNTRY
                 where       COUNTRIES.DESCRIPTION = 'United States' and
                             STATES.TAX_RATE >= 3.0 and
                             HOUSEHOLDS.CITY = 'Denver')
              HOUSEHOLDS_SUBQUERY on INDIVIDUALS.HOUSEHOLD =
              HOUSEHOLDS_SUBQUERY.HOUSEHOLD
  join        GENDERS on INDIVIDUALS.GENDER = GENDERS.GENDER
  where       GENDERS.DESCRIPTION = 'Male' and
              INDIVIDUALS.NAME = 'Brown';

explain

