; Optimize a query against a single table requesting a distinct count 
; with nested subqueries as criteria

set           timer on

select        count(distinct COUNTRY)
  from        COUNTRIES
  where       COUNTRY in
              (select        distinct COUNTRY
                 from          STATES
                 where       TAX_RATE = 'MA') and
              COUNTRY in
              (select        distinct COUNTRY
                from         HOUSEHOLDS
                where        HOUSEHOLD in
                             (select        distinct HOUSEHOLD
                                from        INDIVIDUALS
                                where       (INDIVIDUALS.GENDER = 'M' or
                                             INDIVIDUALS.NAME = 'William')));


explain


