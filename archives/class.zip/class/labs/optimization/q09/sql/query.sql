; Optimize a query against a fact table in a Star Schema with grouped 
; aggregations from multiple dimension and snowflake tables.

set timer on

select        COUNTRIES.DESCRIPTION,
              STATES.REGION,
              GENDERS.DESCRIPTION,
              count(*)
  from        HOUSEHOLDS
  join        INDIVIDUALS on HOUSEHOLDS.HOUSEHOLD = INDIVIDUALS.HOUSEHOLD
  join        STATES on HOUSEHOLDS.STATE = STATES.STATE
  join        COUNTRIES on STATES.COUNTRY = COUNTRIES.COUNTRY
  join        GENDERS on INDIVIDUALS.GENDER = GENDERS.GENDER
  where       HOUSEHOLDS.CITY = 'YORK' and
              STATES.TAX_RATE > 3.0
  group by    COUNTRIES.DESCRIPTION,
              STATES.REGION,
              GENDERS.DESCRIPTION;

explain
