;Optimize a query against two tables with criteria in each table

set timer on

select        count(*)
  from        HOUSEHOLDS
  join        INDIVIDUALS on HOUSEHOLDS.HOUSEHOLD = INDIVIDUALS.HOUSEHOLD
  where       STATE = 'CA' and
              NAME = 'William';
explain
