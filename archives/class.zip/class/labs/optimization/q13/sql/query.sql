; Optimize a query that joins to subqueries

set timer on

select        count(*)
  from        (select        INDIVIDUAL,
                             HOUSEHOLD
                 from        INDIVIDUALS
                 join        GENDERS on INDIVIDUALS.GENDER = GENDERS.GENDER
                 where       GENDERS.DESCRIPTION = 'Male' and
                             INDIVIDUALS.NAME = 'Brown')
              INDIVIDUALS_SUBQUERY
  join        (select        HOUSEHOLD
                 from        HOUSEHOLDS
                 join        STATES on HOUSEHOLDS.STATE = STATES.STATE
                 join        COUNTRIES on STATES.COUNTRY = COUNTRIES.COUNTRY
                 where       COUNTRIES.DESCRIPTION = 'United States' and
                             STATES.TAX_RATE >= 3.0 and
                             HOUSEHOLDS.CITY = 'Denver')
              HOUSEHOLDS_SUBQUERY 
              on INDIVIDUALS_SUBQUERY.HOUSEHOLD = HOUSEHOLDS_SUBQUERY.HOUSEHOLD;

explain

