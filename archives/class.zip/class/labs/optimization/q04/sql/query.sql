; Optimize a query against a table joined to many dimension tables with 
; multiple criteria

set timer on

select        count(*)
  from        HOUSEHOLDS
  join        INDIVIDUALS on HOUSEHOLDS.HOUSEHOLD = INDIVIDUALS.HOUSEHOLD
  join        STATES on HOUSEHOLDS.STATE = STATES.STATE
  join        COUNTRIES on STATES.COUNTRY = COUNTRIES.COUNTRY
  join        GENDERS on INDIVIDUALS.GENDER = GENDERS.GENDER
  where       COUNTRIES.DESCRIPTION = 'United States' and
              STATES.REGION = 'PC' and
              TAX_RATE > 3.0 and
              GENDERS.DESCRIPTION = 'Male' and
              INDIVIDUALS.NAME = 'William';

explain


