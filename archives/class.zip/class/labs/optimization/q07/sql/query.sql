; Optimize a query against a table with counts grouped by columns
; in dimension tables

set timer on

select        COUNTRIES.DESCRIPTION,
              STATES.REGION,
              count(*)
  from        STATES
  join        COUNTRIES on STATES.COUNTRY = COUNTRIES.COUNTRY
  group by    COUNTRIES.DESCRIPTION,
              STATES.REGION;

explain
