; Optimize a query against a table with aggregations grouped by columns
; in dimension tables

set timer on

select        COUNTRIES.DESCRIPTION,
              STATES.REGION,
              sum(STATES.TAX_RATE),
              avg(STATES.TAX_RATE),
              count(*)
  from        STATES
  join        COUNTRIES on STATES.COUNTRY = COUNTRIES.COUNTRY
  group by    COUNTRIES.DESCRIPTION,
              STATES.REGION;

explain
