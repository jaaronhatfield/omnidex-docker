; Optimize a query against a single table obtaining a distinct count 
; against a column other than the primary key

set           timer on

select        count(distinct HOUSEHOLD)
  from        INDIVIDUALS
  where       GENDER = 'M' or
              NAME = 'William';

explain

