; q01/sql/query.sql
; Optimize a query against a single table with one piece of criteria

set timer on

select        count(*)
  from        INDIVIDUALS
  where       HOUSEHOLD = '009064054622';

explain

; q02/sql/query.sql
;Optimize a query against a single table with multiple criteria

set timer on

select        count(*)
  from        INDIVIDUALS
  where       NAME = 'William' and
              BIRTHDATE >= 'Jan 1, 1980';

explain

; q03/sql/query.sql
;Optimize a query against two tables with criteria in each table

set timer on

select        count(*)
  from        HOUSEHOLDS
  join        INDIVIDUALS on HOUSEHOLDS.HOUSEHOLD = INDIVIDUALS.HOUSEHOLD
  where       STATE = 'CA' and
              NAME = 'William';
explain

; q04/sql/query.sql
; Optimize a query against a table joined to many dimension tables with 
; multiple criteria

set timer on

select        count(*)
  from        HOUSEHOLDS
  join        INDIVIDUALS on HOUSEHOLDS.HOUSEHOLD = INDIVIDUALS.HOUSEHOLD
  join        STATES on HOUSEHOLDS.STATE = STATES.STATE
  join        COUNTRIES on STATES.COUNTRY = COUNTRIES.COUNTRY
  join        GENDERS on INDIVIDUALS.GENDER = GENDERS.GENDER
  where       COUNTRIES.DESCRIPTION = 'United States' and
              STATES.REGION = 'PC' and
              TAX_RATE > 3.0 and
              GENDERS.DESCRIPTION = 'Male' and
              INDIVIDUALS.NAME = 'William';

explain


; q05/sql/query.sql
; Optimize a query against a single table with grouped counts

set timer on

select        REGION,
              count(*)
  from        STATES
  group by    REGION;

explain

; q06/sql/query.sql
; Optimize a query against a single table with grouped aggregations

set timer on

select        REGION,
              sum(TAX_RATE),
              avg(TAX_RATE),
              count(*)
  from        STATES
  group by    REGION;

explain

; q07/sql/query.sql
; Optimize a query against a table with counts grouped by columns
; in dimension tables

set timer on

select        COUNTRIES.DESCRIPTION,
              STATES.REGION,
              count(*)
  from        STATES
  join        COUNTRIES on STATES.COUNTRY = COUNTRIES.COUNTRY
  group by    COUNTRIES.DESCRIPTION,
              STATES.REGION;

explain

; q08/sql/query.sql
; Optimize a query against a table with aggregations grouped by columns
; in dimension tables

set timer on

select        COUNTRIES.DESCRIPTION,
              STATES.REGION,
              sum(STATES.TAX_RATE),
              avg(STATES.TAX_RATE),
              count(*)
  from        STATES
  join        COUNTRIES on STATES.COUNTRY = COUNTRIES.COUNTRY
  group by    COUNTRIES.DESCRIPTION,
              STATES.REGION;

explain

; q09/sql/query.sql
; Optimize a query against a fact table in a Star Schema with grouped 
; aggregations from multiple dimension and snowflake tables.

set timer on

select        COUNTRIES.DESCRIPTION,
              STATES.REGION,
              GENDERS.DESCRIPTION,
              count(*)
  from        HOUSEHOLDS
  join        INDIVIDUALS on HOUSEHOLDS.HOUSEHOLD = INDIVIDUALS.HOUSEHOLD
  join        STATES on HOUSEHOLDS.STATE = STATES.STATE
  join        COUNTRIES on STATES.COUNTRY = COUNTRIES.COUNTRY
  join        GENDERS on INDIVIDUALS.GENDER = GENDERS.GENDER
  where       HOUSEHOLDS.CITY = 'YORK' and
              STATES.TAX_RATE > 3.0
  group by    COUNTRIES.DESCRIPTION,
              STATES.REGION,
              GENDERS.DESCRIPTION;

explain

; q10/sql/query.sql
; Optimize a query against a single table with subqueries as criteria

set           timer on

select        count(*)
  from        INDIVIDUALS
  where       INDIVIDUAL in
              (select        INDIVIDUAL
                 from        INDIVIDUALS
                 where       GENDER = 'M') and
              INDIVIDUAL in
              (select        INDIVIDUAL
                 from        INDIVIDUALS
                 where       NAME = 'William');

explain

; q11/sql/query.sql
; Optimize a query against a multiple tables with multiple criteria

set timer on

select        count(*)
  from        INDIVIDUALS
  join        HOUSEHOLDS on INDIVIDUALS.HOUSEHOLD = HOUSEHOLDS.HOUSEHOLD
  join        STATES on HOUSEHOLDS.STATE = STATES.STATE
  join        COUNTRIES on STATES.COUNTRY = COUNTRIES.COUNTRY
  join        GENDERS on INDIVIDUALS.GENDER = GENDERS.GENDER
  where       COUNTRIES.DESCRIPTION = 'United States' and
              STATES.TAX_RATE >= 3.0 and
              HOUSEHOLDS.CITY = 'Denver' and
              INDIVIDUALS.NAME = 'Brown' and
              GENDERS.DESCRIPTION = 'Male';

explain


; Optimize the same query written to use subqueries
select        count(*)
  from        INDIVIDUALS
  where       HOUSEHOLD in
              (select        HOUSEHOLD
                 from        HOUSEHOLDS
                 where       CITY = 'Denver' and
                             STATE in
                             (select        STATE
                                from        STATES
                                where       TAX_RATE >= 3.0 and
                                            COUNTRY in
                                            (select        COUNTRY
                                               from        COUNTRIES
                                               where       DESCRIPTION =
                                                           'United States')))
              and
              GENDER in
              (select        GENDER
                 from        GENDERS
                 where       DESCRIPTION = 'Male') and
              NAME = 'Brown';

explain

; q12/sql/query.sql
; Optimize a query that joins to subqueries

set timer on

select        count(*)
  from        INDIVIDUALS
  join        (select        HOUSEHOLD
                 from        HOUSEHOLDS
                 join        STATES on HOUSEHOLDS.STATE = STATES.STATE
                 join        COUNTRIES on STATES.COUNTRY = COUNTRIES.COUNTRY
                 where       COUNTRIES.DESCRIPTION = 'United States' and
                             STATES.TAX_RATE >= 3.0 and
                             HOUSEHOLDS.CITY = 'Denver')
              HOUSEHOLDS_SUBQUERY on INDIVIDUALS.HOUSEHOLD =
              HOUSEHOLDS_SUBQUERY.HOUSEHOLD
  join        GENDERS on INDIVIDUALS.GENDER = GENDERS.GENDER
  where       GENDERS.DESCRIPTION = 'Male' and
              INDIVIDUALS.NAME = 'Brown';

explain

; q13/sql/query.sql
; Optimize a query that joins to subqueries

set timer on

select        count(*)
  from        (select        INDIVIDUAL,
                             HOUSEHOLD
                 from        INDIVIDUALS
                 join        GENDERS on INDIVIDUALS.GENDER = GENDERS.GENDER
                 where       GENDERS.DESCRIPTION = 'Male' and
                             INDIVIDUALS.NAME = 'Brown')
              INDIVIDUALS_SUBQUERY
  join        (select        HOUSEHOLD
                 from        HOUSEHOLDS
                 join        STATES on HOUSEHOLDS.STATE = STATES.STATE
                 join        COUNTRIES on STATES.COUNTRY = COUNTRIES.COUNTRY
                 where       COUNTRIES.DESCRIPTION = 'United States' and
                             STATES.TAX_RATE >= 3.0 and
                             HOUSEHOLDS.CITY = 'Denver')
              HOUSEHOLDS_SUBQUERY 
              on INDIVIDUALS_SUBQUERY.HOUSEHOLD = HOUSEHOLDS_SUBQUERY.HOUSEHOLD;

explain

; q14/sql/query.sql
; Optimize a query against a single table obtaining a distinct count 
; against the primary key

set           timer on

select        count(distinct INDIVIDUAL)
  from        INDIVIDUALS
  where       GENDER = 'M' or
              NAME = 'William';

explain

; q15/sql/query.sql
; Optimize a query against a single table obtaining a distinct count 
; against a column other than the primary key

set           timer on

select        count(distinct HOUSEHOLD)
  from        INDIVIDUALS
  where       GENDER = 'M' or
              NAME = 'William';

explain

; q16/sql/query.sql
; Optimize a query against a multiple tables requesting a distinct count 
; against the primary key.

set           timer on

select        count(distinct HOUSEHOLDS.HOUSEHOLD)
  from        HOUSEHOLDS
  join        INDIVIDUALS on HOUSEHOLDS.HOUSEHOLD = INDIVIDUALS.HOUSEHOLD
  where       HOUSEHOLDS.STATE = 'CA' and
              (INDIVIDUALS.GENDER = 'M' or
               INDIVIDUALS.NAME = 'William');

explain

; q17/sql/query.sql
; Optimize a query against many tables requesting a grouped distinct 
; count against a non-primary key

set           timer on

select        count(distinct INDIVIDUALS.HOUSEHOLD)
  from        STATES 
  join        HOUSEHOLDS on STATES.STATE = HOUSEHOLDS.STATE
  join        INDIVIDUALS on HOUSEHOLDS.HOUSEHOLD = INDIVIDUALS.HOUSEHOLD
  where       STATES.TAX_RATE > 3.0 and
              (INDIVIDUALS.GENDER = 'M' or
               INDIVIDUALS.NAME = 'William');

explain

; q18/sql/query.sql
; Optimize a query against many tables requesting a grouped distinct 
; count against a non-primary key in the middle of a table hierarchy

set           timer on

select        count(distinct HOUSEHOLDS.ZIP)
  from        STATES 
  join        HOUSEHOLDS on STATES.STATE = HOUSEHOLDS.STATE
  join        INDIVIDUALS on HOUSEHOLDS.HOUSEHOLD = INDIVIDUALS.HOUSEHOLD
  where       STATES.TAX_RATE > 3.0 and
              (INDIVIDUALS.GENDER = 'M' or
               INDIVIDUALS.NAME = 'William');

explain

; q19/sql/query.sql
; Optimize a query against a single table requesting a distinct count 
; with nested subqueries as criteria

set           timer on

select        count(distinct COUNTRY)
  from        COUNTRIES
  where       COUNTRY in
              (select        distinct COUNTRY
                 from          STATES
                 where       TAX_RATE = 'MA') and
              COUNTRY in
              (select        distinct COUNTRY
                from         HOUSEHOLDS
                where        HOUSEHOLD in
                             (select        distinct HOUSEHOLD
                                from        INDIVIDUALS
                                where       (INDIVIDUALS.GENDER = 'M' or
                                             INDIVIDUALS.NAME = 'William')));


explain

; q20/sql/query.sql
; Optimize a query against one table with an aggregation of an expression,
; an expression of an aggregation and criteria of an expression.

select        REGION,
              COUNT(*) * AVG(TAX_RATE),
              AVG(TAX_RATE * 2)
  from        STATES
  where       SUBSTRING(STATE from 1 for 1) = 'C'
  group by    REGION;

explain

