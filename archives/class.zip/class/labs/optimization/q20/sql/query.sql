; Optimize a query against one table with an aggregation of an expression,
; an expression of an aggregation and criteria of an expression.

select        REGION,
              COUNT(*) * AVG(TAX_RATE),
              AVG(TAX_RATE * 2)
  from        STATES
  where       SUBSTRING(STATE from 1 for 1) = 'C'
  group by    REGION;

explain

