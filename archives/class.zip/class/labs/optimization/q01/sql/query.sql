; Optimize a query against a single table with one piece of criteria

set timer on

select        count(*)
  from        INDIVIDUALS
  where       HOUSEHOLD = '009064054622';

explain

