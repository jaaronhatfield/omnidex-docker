connect to    simple.xml

export        (select        *
                 from        COUNTRIES)
  to          dat/countries.csv
  with        TDF COLUMN=',' RECORD=\r\n QUOTES DELETE;

export        (select        *
                 from        STATES)
  to          dat/states.txt
  with        TDF COLUMN=\t RECORD=\r\n QUOTES DELETE;

export        (select        *
                 from        GENDERS)
  to          dat/genders.txt
  with        TDF COLUMN=| RECORD=\r\n QUOTES DELETE;

export        (select        *
                 from        HOUSEHOLDS)
  to          dat/households.txt
  with        TDF COLUMN=## RECORD=\n QUOTES DELETE;

export        (select        *
                 from        INDIVIDUALS)
  to          dat/individuals.txt
  with        TDF COLUMN=%% RECORD=~~ QUOTES DELETE;

disconnect
