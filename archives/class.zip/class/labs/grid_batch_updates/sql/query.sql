connect simplegrid

set pagelength 0

select count(*) from households;
select count(*) from individuals;

select count(*) from households where address = '123 MAIN ST';
select count(*) from individuals where email = 'johndoe@email.com';

