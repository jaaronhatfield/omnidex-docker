connect simplegrid

; Copy the new record images for each table, reflecting all inserts and updates.
copy dat/after/households_inserts1.txt dat/households_inserts.txt with delete
copy dat/after/individuals_inserts1.txt dat/individuals_inserts.txt with delete

; Copy the new primary keys for deleted rows for each table
copy dat/after/households_deletes1.txt dat/households_deletes.txt with delete
copy dat/after/individuals_deletes1.txt dat/individuals_deletes.txt with delete

; Update the OFX files for these delimited files
update delimited

; Apply updates
apply updates
