use sql/simplegrid.sql

create file dat/households_deletes.txt with delete
create file dat/households_inserts.txt with delete
create file dat/individuals_deletes.txt with delete
create file dat/individuals_inserts.txt with delete


connect simplegrid.xml

update indexes;

disconnect
