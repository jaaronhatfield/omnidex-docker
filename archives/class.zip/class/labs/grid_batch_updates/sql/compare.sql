; These steps will export the HOUSEHOLDS and INDIVIDUALS table and compare them 
; against exports from the basic simple database to insure that they match.

connect simplegrid

export select * from households order by household to dat/after/households_test.txt with delimited, delete;
export select * from individuals order by individual to dat/after/individuals_test.txt with delimited, delete;

; Compare HOUSEHOLDS
diff dat/after/households_final.txt dat/after/households_test.txt with ascii

; Compare INDIVIDUALS
diff dat/after/individuals_final.txt dat/after/individuals_test.txt with ascii

