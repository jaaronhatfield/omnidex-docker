;use sql/simplegrid.sql

; Insure we are starting with the correct "before" image.  The "before" 
; image has an empty $UPDATES node.  

copy dat/before/*.* dat with delete

; Connect to simplegrid
connect simplegrid.xml

; Load the OFX files for these delimited files
update delimited

; Update the Omnidex indexes 
update indexes


