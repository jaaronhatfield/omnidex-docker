; Analyze individuals by their age group and domain name

select        AGE_GROUP,
              EMAIL_DOMAIN,
              count(*)
  from        INDIVIDUALS
  where       AGE >= 18 and
              substring(PHONE from 2 for 3) > ' '
  group by    AGE_GROUP,
              EMAIL_DOMAIN
  having      count(*) > 10;

explain

