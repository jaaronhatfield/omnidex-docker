create environment    
 max_threads          2
 node                 "NODE01" 
   connectionstring   "[localhost:7555]d:/class/lab4/simplegrid.xml[node01]"
   partitioned 
 node                 "NODE02" 
   connectionstring   "[localhost:7555]d:/class/lab4/simplegrid.xml[node02]"
   partitioned 
 in                   "simplegrid.xml"
 with                 delete;


create database       "SIMPLE"
 node "NODE01"
  type                FILE
  index_directory     "idx/NODE01"
 node "NODE02"
  type                FILE
  index_directory     "idx/NODE02"
 in                   "simplegrid.xml";


create table          "COUNTRIES"
 physical             "dat/cnt.dat"
 (
  "COUNTRY"           CHARACTER(2),               
  "DESCRIPTION"       STRING(47),                
  "LATITUDE"          FLOAT                          usage "LATITUDE",
  "LONGITUDE"         FLOAT                          usage "LONGITUDE",
  "CAPITAL"           STRING(31),               
  "CAPITAL_LAT"       FLOAT                          usage "LATITUDE",
  "CAPITAL_LONG"      FLOAT                          usage "LONGITUDE",
  constraint COUNTRIES_COUNTRY_PK primary ("COUNTRY")
 )
 in                   "simplegrid.xml";


create table          "STATES"
 physical             "dat/sta.dat"
 (
  "STATE"             CHARACTER(2),                
  "DESCRIPTION"       STRING(31),                 
  "STATE_CODE"        CHARACTER(2),                
  "REGION"            CHARACTER(2),                
  "COUNTRY"           CHARACTER(2),                
  "TAX_RATE"          FLOAT,                       
  constraint STATES_STATE_PK primary ("STATE"),
  constraint STATES_COUNTRY_FK foreign ("COUNTRY") references "COUNTRIES"
 )
 in                   "simplegrid.xml";


create table          "GENDERS"
 physical             "dat/gdr.dat"
 (
  "GENDER"            CHARACTER(1),                
  "DESCRIPTION"       STRING(31),                  
  constraint GENDERS_GENDER_PK primary ("GENDER")
 )
 in                   "simplegrid.xml";


create table          "HOUSEHOLDS"
 node "NODE01"
  physical            "dat/households01.dat"
  partition_by        "STATE in ('NY','PR','MA','RI','ME','NH','VT','CT','NJ',
                                 'PA','DE','DC','MD','VA','WV','NC','SC','GA',
                                 'FL','AL','TN','MS','KY','OH') and 
                       ZIP between '01000' and '45999'"
 node "NODE02"
  physical            "dat/households02.dat"
  partition_by        "STATE in ('IN','MI','IA','WI','MN','SD','ND','MT','IL',
                                 'MO','KS','NE','LA','AR','OK','TX','TX','CO',
                                 'WY','ID','UT','AZ','NM','NV','CA','HI','OR',
                                 'WA','AK') and 
                       ZIP between '46000' and '99999'"
 (
  "HOUSEHOLD"         CHARACTER(12),               
  "ADDRESS"           CHARACTER(50),               
  "CITY"              CHARACTER(28),               
  "STATE"             CHARACTER(2),                
  "ZIP"               CHARACTER(5),                
  "COUNTRY"           CHARACTER(2),                
  constraint HSHD_HOUSEHOLD_PK primary ("HOUSEHOLD"),
  constraint HSHD_STATE_FK foreign ("STATE") references "STATES",
  constraint HSHD_COUNTRY_FK foreign ("COUNTRY") references "COUNTRIES"
 )
 in                   "simplegrid.xml";


create table          "INDIVIDUALS"
 node "NODE01"
  physical            "dat/individuals01.dat"
  partition_by        "HOUSEHOLDS.HOUSEHOLD = INDIVIDUALS.HOUSEHOLD and 
                       STATE in ('NY','PR','MA','RI','ME','NH','VT','CT','NJ',
                                 'PA','DE','DC','MD','VA','WV','NC','SC','GA',
                                 'FL','AL','TN','MS','KY','OH') and 
                       ZIP between '01000' and '45999'"
 node "NODE02"
  physical            "dat/individuals02.dat"
  partition_by        "HOUSEHOLDS.HOUSEHOLD = INDIVIDUALS.HOUSEHOLD and 
                       STATE in ('IN','MI','IA','WI','MN','SD','ND','MT','IL',
                                 'MO','KS','NE','LA','AR','OK','TX','TX','CO',
                                 'WY','ID','UT','AZ','NM','NV','CA','HI','OR',
                                 'WA','AK') and 
                       ZIP between '46000' and '99999'"
 (
  "INDIVIDUAL"        CHARACTER(12),               
  "HOUSEHOLD"         CHARACTER(12),               
  "NAME"              CHARACTER(50),                
  "GENDER"            CHARACTER(1),                    
  "BIRTHDATE"         ANSI DATE,                
  "PHONE"             CHARACTER(14),               
  "EMAIL"             CHARACTER(60),                  
  constraint IND_INDIVIDUAL_PK primary ("INDIVIDUAL"),
  constraint IND_HOUSEHOLD_FK foreign ("HOUSEHOLD") references "HOUSEHOLDS",
  constraint IND_GENDER_FK foreign ("GENDER") references "GENDERS",
 )
 in                   "simplegrid.xml";
