connect to simple

export 
  select      household, 
              case 
               when STATE in ('NY','PR','MA','RI','ME','NH','VT','CT','NJ',
                              'PA','DE','DC','MD','VA','WV','NC','SC','GA',
                              'FL','AL','TN','MS','KY','OH') 
               then '01' 
               when state in ('IN','MI','IA','WI','MN','SD','ND','MT','IL',
                              'MO','KS','NE','LA','AR','OK','TX','TX','CO',
                              'WY','ID','UT','AZ','NM','NV','CA','HI','OR',
                              'WA','AK') 
               then '02' 
               else '03' 
               end partitionid
              from households
  to          partitionids 
  with        ost, delete;


attach ost    partitionids as partitionids;


export 
  select      households.*
  from        households
  join        partitionids on households.household = partitionids.household
  where       partitionid = '01' 
  to          dat/households01.dat
  with        delete;

export 
  select      households.*
  from        households
  join        partitionids on households.household = partitionids.household
  where       partitionid = '02' 
  to          dat/households02.dat
  with        delete;

export 
  select      individuals.*
  from        individuals
  join        partitionids on individuals.household = partitionids.household
  where       partitionid = '01' 
  to          dat/individuals01.dat
  with        delete;

export 
  select      individuals.*
  from        individuals
  join        partitionids on individuals.household = partitionids.household
  where       partitionid = '02' 
  to          dat/individuals02.dat
  with        delete;

detach ost   partitionids with delete;


disconnect
