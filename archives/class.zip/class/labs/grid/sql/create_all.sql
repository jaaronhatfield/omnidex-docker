; Partition the data for a grid 
use sql/simple.sql

use sql/partition.sql

use sql/simplegrid.sql 

