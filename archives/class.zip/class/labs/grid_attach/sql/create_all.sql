
; SIMPLE Database
use sql/simplegrid.sql

connect simplegrid.xml

update indexes;

disconnect


; GEO Database
use sql/geo.sql

connect geo.xml

update indexes;

disconnect
