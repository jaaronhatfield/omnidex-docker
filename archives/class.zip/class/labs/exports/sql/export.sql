connect simple.xml

; Example #1 - Export primary keys to be used as criteria in another 
; application.  This application requires a fixed-length data file rather 
; than a delimited file.  Note that Omnidex Data Segments can be used for this
; purpose as well.

export        (select        INDIVIDUALS.INDIVIDUAL
                 from        INDIVIDUALS
                 join        HOUSEHOLDS on INDIVIDUALS.HOUSEHOLD =
                             HOUSEHOLDS.HOUSEHOLD
                 where       ((HOUSEHOLDS.STATE = 'CO' and
                               HOUSEHOLDS.CITY = 'Denver') or
                              (HOUSEHOLDS.STATE = 'AZ' and
                               HOUSEHOLDS.CITY = 'Phoenix')) and
                             INDIVIDUALS.BIRTHDATE > 'January 1, 1980')
  to          dat/export1.dat
  with        delete, hdc_threshold=1024MB;


; Example #2 - Export data to be used in another application.  This application
; expects a tab-delimited file with a header row.

; Note that this statement uses  an especially large HDC_THRESHOLD so that
; the Hashed Data Cache can be used even when the tables are quite large.

export        (select        HOUSEHOLDS.HOUSEHOLD,
                             HOUSEHOLDS.ADDRESS,
                             HOUSEHOLDS.CITY,
                             HOUSEHOLDS.STATE,
                             STATES.DESCRIPTION,
                             STATES.REGION,
                             STATES.TAX_RATE,
                             HOUSEHOLDS.ZIP,
                             HOUSEHOLDS.COUNTRY,
                             COUNTRIES.DESCRIPTION,
                             INDIVIDUALS.INDIVIDUAL,
                             INDIVIDUALS.NAME,
                             INDIVIDUALS.GENDER,
                             GENDERS.DESCRIPTION,
                             INDIVIDUALS.BIRTHDATE,
                             cast($compare_dates(INDIVIDUALS.BIRTHDATE,
                             current_date, 'YY') as integer) AGE,
                             cast(substring(INDIVIDUALS.PHONE from 2 for 3)
                             as character(3)) PHONE_AREACODE,
                             cast(substring(INDIVIDUALS.PHONE from 7 for 3)
                             as character(3)) PHONE_PREFIX,
                             cast(substring(INDIVIDUALS.PHONE from 11 for 4)
                             as character(4)) PHONE_SUFFIX,
                             INDIVIDUALS.EMAIL
                 from        INDIVIDUALS
                 join        HOUSEHOLDS on INDIVIDUALS.HOUSEHOLD =
                             HOUSEHOLDS.HOUSEHOLD
                 join        STATES on HOUSEHOLDS.STATE = STATES.STATE
                 join        COUNTRIES on STATES.COUNTRY = COUNTRIES.COUNTRY
                 join        GENDERS on INDIVIDUALS.GENDER = GENDERS.GENDER
                 where       ((HOUSEHOLDS.STATE = 'CO' and
                               HOUSEHOLDS.CITY = 'Denver') or
                              (HOUSEHOLDS.STATE = 'AZ' and
                               HOUSEHOLDS.CITY = 'Phoenix')) and
                             INDIVIDUALS.BIRTHDATE > 'January 1, 1980')
  to          dat/export2.txt
  with        delimited, header_row, delete, hdc_threshold=1024MB;


; Example #3 - Export aggregated data to be imported into a spreadsheet.
; The spreadsheet expects a coma-delimited file with a header row.

export        (select        HOUSEHOLDS.STATE,
                             INDIVIDUALS.GENDER,
                             count(*)
                 from        INDIVIDUALS
                 join        HOUSEHOLDS on INDIVIDUALS.HOUSEHOLD =
                             HOUSEHOLDS.HOUSEHOLD
                 where       ((HOUSEHOLDS.STATE = 'CO' and
                               HOUSEHOLDS.CITY = 'Denver') or
                              (HOUSEHOLDS.STATE = 'AZ' and
                               HOUSEHOLDS.CITY = 'Phoenix')) and
                             INDIVIDUALS.BIRTHDATE > 'January 1, 1980' 
                 group by    HOUSEHOLDS.STATE,
                             INDIVIDUALS.GENDER)
  to          dat/export3.txt
  with        delimited, header_row, column=',' delete, hdc_threshold=1024MB;


disconnect