use sql/simple.sql

connect simple.xml

update indexes;

; Update statistics to further improve performance optimization 
update statistics;

disconnect

