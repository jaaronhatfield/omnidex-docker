set pagelength 0

; Show the temporary directory prior to connecting to the Omnidex environment.
versions tmpdir

; Connect to the Omnidex environment
connect simple

; Show the temporary directory after connecting to the Omnidex environment.
versions tmpdir

; Disconnect from the Omnidex environment
disconnect

; Show the temporary directory after disconnecting from the Omnidex environment.
versions tmpdir

