select        count(*)
  from        HOUSEHOLDS
  where       CITY = 'BOULDER' and
              STATE = 'CO' and
              ZIP = '80301' and
              COUNTRY = 'US';

explain

