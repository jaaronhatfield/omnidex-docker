
; Note that standalone indexes cannot be QuickText or FullText indexes.
create omnidex index "STATE"   on "HOUSEHOLDS" ("STATE")   standalone in "simple.xml";
create omnidex index "ZIP"     on "HOUSEHOLDS" ("ZIP")     standalone in "simple.xml";
create omnidex index "COUNTRY" on "HOUSEHOLDS" ("COUNTRY") standalone in "simple.xml";

; Update the indexes and statistics
connect simple

update indexes for index "HOUSEHOLDS"."STATE";
update indexes for index "HOUSEHOLDS"."ZIP";
update indexes for index "HOUSEHOLDS"."COUNTRY";


update statistics for index "HOUSEHOLDS"."STATE";
update statistics for index "HOUSEHOLDS"."ZIP";
update statistics for index "HOUSEHOLDS"."COUNTRY";

disconnect
