select    I.GENDER, count(*)
  from    HOUSEHOLDS H
  join    INDIVIDUALS I 
    on    H.HOUSEHOLD = I.HOUSEHOLD
 where    ((H.STATE = 'CO' and 
            H.CITY = 'Denver') or
           (H.STATE = 'AZ' and 
            H.CITY = 'Phoenix')) and 
          I.BIRTHDATE > 'January 1, 1980'
group by  I.GENDER;
