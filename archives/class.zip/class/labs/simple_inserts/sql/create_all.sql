use sql/simple.sql

connect simple.xml

; Update the Omnidex indexes to prepare empty index files
update indexes;

; Insert rows 
use sql/inserts.sql with silent

disconnect
