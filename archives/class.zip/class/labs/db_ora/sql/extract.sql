extract       DDL
  for         ORACLE
  to          "simple.sql"
  with        VERSION="11"
              USER="simple"
              PASSWORD="simple"
              DATABASE="simple"
              INDEX_DIRECTORY="idx"