-- Connect as simple to create tables
create table COUNTRIES
       (COUNTRY                 CHAR(2),
        DESCRIPTION             VARCHAR2(47),
        LATITUDE                NUMBER(16,6),
        LONGITUDE               NUMBER(16,6),
        CAPITAL                 VARCHAR2(31),
        CAPITAL_LAT             NUMBER(16,6),
        CAPITAL_LONG            NUMBER(16,6),
        constraint              COUNTRIES_COUNTRY_PK
                                primary key (COUNTRY)
                                using index);

create table STATES
       (STATE                   CHAR(2),
        DESCRIPTION             VARCHAR2(31),
        STATE_CODE              CHAR(2),
        REGION                  CHAR(2),
        COUNTRY                 CHAR(2),
        TAX_RATE                NUMBER(16,6),
        constraint              STATES_STATE_PK
                                primary key (STATE)
                                using index,
        constraint              STATES_COUNTRY_FK
                                foreign key (COUNTRY) 
                                references COUNTRIES(COUNTRY));

create table GENDERS
       (GENDER                  CHAR(1),
        DESCRIPTION             VARCHAR2(31),
        constraint              GENDERS_GENDER_PK
                                primary key (GENDER)
                                using index);

create table HOUSEHOLDS
       (HOUSEHOLD               CHAR(12),
        ADDRESS                 CHAR(50),
        CITY                    CHAR(28),
        STATE                   CHAR(2),
        ZIP                     CHAR(5),
        COUNTRY                 CHAR(2),
        constraint              HOUSEHOLDS_HOUSEHOLD_PK
                                primary key (HOUSEHOLD)
                                using index,
        constraint              HOUSEHOLDS_STATE_FK
                                foreign key (STATE) 
                                references STATES(STATE),
        constraint              HOUSEHOLDS_COUNTRY_FK
                                foreign key (COUNTRY) 
                                references COUNTRIES(COUNTRY));

create table INDIVIDUALS
       (INDIVIDUAL              CHAR(12),
        HOUSEHOLD               CHAR(12),
        NAME                    CHAR(50),
        GENDER                  CHAR(1),
        BIRTHDATE               DATE,
        PHONE                   CHAR(14),
        EMAIL                   CHAR(60),
        constraint              INDIVIDUALS_INDIVIDUAL_PK
                                primary key (INDIVIDUAL)
                                using index,
        constraint              INDIVIDUALS_HOUSEHOLD_FK
                                foreign key (HOUSEHOLD) 
                                references HOUSEHOLDS(HOUSEHOLD),
        constraint              INDIVIDUALS_GENDER_FK
                                foreign key (GENDER) 
                                references GENDERS(GENDER));

commit;

quit;
