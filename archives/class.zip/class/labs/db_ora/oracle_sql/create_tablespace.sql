-- Connect as system manager to create tablespace and user
create tablespace               SIMPLE
        datafile                'simple.dbf'
        size                    10m
        autoextend              on
        nologging;

create user                     SIMPLE
        identified by           simple
        default tablespace      simple;

grant connect, resource, unlimited tablespace, create any synonym to simple;

quit;
