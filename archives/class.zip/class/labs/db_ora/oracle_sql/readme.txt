
The following commands can be used to create the Oracle version of the 
SIMPLE database:


1. This command will build the Oracle tablespace and user.  It can be changed
   as needed to place the data file in the desired location. This command
   should be run from the 'system' user, or an equivalent user with 
   appropriate privileges.

      sqlplus system/manager @oracle_sql/create_tablespace.sql


2. This command will create the Oracle tables and constraints.  This command
   should be run from the 'simple' user.

      sqlplus simple/simple @oracle_sql/create_tables.sql


3. This command will insert the data into the newly created tables.  This 
   command should be run from the 'simple' user.

      sqlplus simple/simple @oracle_sql/insert_data.sql


4. If needed, this command will remove the tablespaces and the user.  It 
   will be necessary to manually delete the data file.  This command should 
   be run from the 'system' user, or an equivalent user with appropriate 
   privileges.

      sqlplus simple/simple @oracle_sql/drop_tablespace.sql



