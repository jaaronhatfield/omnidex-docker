-- Connect as system/manager

drop tablespace simple including contents;
drop user simple;

quit;
