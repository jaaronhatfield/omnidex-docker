
; These environemnt variables can be set within OdxSQL, or can be set at 
; an operating system level.
setenv LOCAL_COUNTRY "US"
setenv LOCAL_STATE   "CO"
setenv SIMPLE_XML    "simple.xml"
setenv SIMPLE_DAT    "dat"
setenv SIMPLE_IDX    "idx"
setenv SIMPLE_SEG    "seg"

; Use an environment variable in a CONNECT statement
connect {$SIMPLE_XML}

; Use an environment variable in an ATTACH TABLE statement
attach table                   "AREACODES"
 physical                      "{$SIMPLE_DAT/arc.dat}"
 (
  "AREACODE"                         character(3),
  "TYPE"                             string(7),
  "TYPE_DESC"                        string(31),
  "ASSIGNABLE"                       character(1),
  "EXPLANATION"                      string(31),
  "RESERVED"                         character(1),
  "ASSIGNED"                         character(1),
  "ASSIGN_DATE"                      ascii date,
  "GEOGRAPHIC"                       character(1),
  "SERVICE"                          string(39),
  "STATES"                           character(10),
  "LOCATION"                         string(31),
  "COUNTRY"                          character(2),
  "AREA_SERVED"                      string(511),
  "IN_SERVICE"                       character(1),
  "IN_SERVICE_DATE"                  ascii date,
  "OVERLAY"                          character(1),
  "OVERLAY_COMPLEX"                  character(20),
  "PARENT"                           character(32),
  "TIME_ZONE1"                       character(1),
  "TIME_ZONE2"                       character(1),
  constraint AREACODES_AREACODE_PK primary ("AREACODE")
 );

; Use an environment variable in an EXPORT statement
export        (select        AREACODE
                 from        AREACODES
                 where       COUNTRY = $getenv('LOCAL_COUNTRY') and 
                             STATES = $getenv('LOCAL_STATE'))
  to          "{$SIMPLE_SEG/local_areacodes.dat}"
  with        delete;

; Use an environmnet variable in an ATTACH DATA SEGMENT statement
attach data segment            LOCAL_AREACODES
 physical                      "{$SIMPLE_SEG/local_areacodes.dat}";

; Reference environment variables in a SELECT statement
select        $getenv('LOCAL_COUNTRY'),
              $getenv('LOCAL_STATE'),
              NAME,
              PHONE
  from        INDIVIDUALS
  where       AREACODE in $segment(LOCAL_AREACODES);


