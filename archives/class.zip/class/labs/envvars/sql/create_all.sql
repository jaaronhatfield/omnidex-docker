; These environemnt variables can be set within OdxSQL, or can be set at 
; an operating system level.
setenv SIMPLE_XML "simple.xml"
setenv SIMPLE_SQL "sql"
setenv SIMPLE_DAT "dat"
setenv SIMPLE_IDX "idx"

use {$SIMPLE_SQL/simple.sql}

connect {$SIMPLE_XML}

update indexes;

disconnect
