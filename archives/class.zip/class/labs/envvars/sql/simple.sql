create environment    
 in                   "{$SIMPLE_XML}"
 with                 delete;


create database       "SIMPLE"
  type                FILE
  index_directory     "{$SIMPLE_IDX}"
 in                   "{$SIMPLE_XML}";


create table          "COUNTRIES"
 physical             "{$SIMPLE_DAT/cnt.dat}"
 (
  "COUNTRY"           CHARACTER(2)      omnidex,
  "DESCRIPTION"       STRING(47)        quicktext,
  "LATITUDE"          FLOAT             omnidex      usage "LATITUDE",
  "LONGITUDE"         FLOAT             omnidex      usage "LONGITUDE",
  "CAPITAL"           STRING(31)        quicktext,
  "CAPITAL_LAT"       FLOAT             omnidex      usage "LATITUDE",
  "CAPITAL_LONG"      FLOAT             omnidex      usage "LONGITUDE",
  constraint COUNTRIES_COUNTRY_PK primary ("COUNTRY")
 )
 in                   "{$SIMPLE_XML}";


create table          "STATES"
 physical             "{$SIMPLE_DAT/sta.dat}"
 (
  "STATE"             CHARACTER(2)      omnidex,
  "DESCRIPTION"       STRING(31)        quicktext,
  "STATE_CODE"        CHARACTER(2)      omnidex,
  "REGION"            CHARACTER(2)      omnidex,
  "COUNTRY"           CHARACTER(2)      omnidex,
  "TAX_RATE"          FLOAT             omnidex,
  constraint STATES_STATE_PK primary ("STATE"),
  constraint STATES_COUNTRY_FK foreign ("COUNTRY") references "COUNTRIES"
 )
 in                   "{$SIMPLE_XML}";


create table          "GENDERS"
 physical             "{$SIMPLE_DAT/gdr.dat}"
 (
  "GENDER"            CHARACTER(1)      omnidex,
  "DESCRIPTION"       STRING(31)        quicktext,
  constraint GENDERS_GENDER_PK primary ("GENDER")
 )
 in                   "{$SIMPLE_XML}";


create table          "HOUSEHOLDS"
 physical             "{$SIMPLE_DAT/households.dat}"
 (
  "HOUSEHOLD"         CHARACTER(12)     omnidex,
  "ADDRESS"           CHARACTER(50)     quicktext,
  "CITY"              CHARACTER(28)     quicktext,
  "STATE"             CHARACTER(2)      omnidex,
  "ZIP"               CHARACTER(5)      omnidex,
  "COUNTRY"           CHARACTER(2)      omnidex,
  constraint HOUSEHOLDS_HOUSEHOLD_PK primary ("HOUSEHOLD"),
  constraint HOUSEHOLDS_STATE_FK foreign ("STATE") references "STATES",
  constraint HOUSEHOLDS_COUNTRY_FK foreign ("COUNTRY") references "COUNTRIES"
 )
 in                   "{$SIMPLE_XML}";


create table          "INDIVIDUALS"
 physical             "{$SIMPLE_DAT/individuals.dat}"
 (
  "INDIVIDUAL"        CHARACTER(12)     omnidex,
  "HOUSEHOLD"         CHARACTER(12)     omnidex,
  "NAME"              CHARACTER(50)     quicktext,
  "GENDER"            CHARACTER(1)      omnidex bitmap,
  "BIRTHDATE"         ANSI DATE         omnidex,
  "PHONE"             CHARACTER(14)     omnidex,
  "EMAIL"             CHARACTER(60)     quicktext,
  "AREACODE"          CHARACTER(3)      omnidex
    as "substring(PHONE from 2 for 3)",
  constraint INDIVIDUALS_INDIVIDUAL_PK primary ("INDIVIDUAL"),
  constraint INDIVIDUALS_HOUSEHOLD_FK foreign ("HOUSEHOLD") references "HOUSEHOLDS",
  constraint INDIVIDUALS_GENDER_FK foreign ("GENDER") references "GENDERS",
 )
 in                   "{$SIMPLE_XML}";
