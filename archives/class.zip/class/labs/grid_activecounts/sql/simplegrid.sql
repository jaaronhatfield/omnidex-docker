create environment    
 max_threads          2
 node                 "NODE01" partitioned
 node                 "NODE02" partitioned
 in                   "simplegrid.xml"
 with                 delete;


create database       "SIMPLE"
 controller
  index_directory     "idx"
 node "NODE01"
  type                FILE
  index_directory     "idx/NODE01"
 node "NODE02"
  type                FILE
  index_directory     "idx/NODE02"
 in                   "simplegrid.xml";


create table          "COUNTRIES"
 physical             "dat/cnt.dat"
 (
  "COUNTRY"           CHARACTER(2)      omnidex,
  "DESCRIPTION"       STRING(47)        quicktext,
  "LATITUDE"          FLOAT             omnidex      usage "LATITUDE",
  "LONGITUDE"         FLOAT             omnidex      usage "LONGITUDE",
  "CAPITAL"           STRING(31)        quicktext,
  "CAPITAL_LAT"       FLOAT             omnidex      usage "LATITUDE",
  "CAPITAL_LONG"      FLOAT             omnidex      usage "LONGITUDE",
  constraint COUNTRIES_COUNTRY_PK primary ("COUNTRY")
 )
 in                   "simplegrid.xml";


create table          "STATES"
 physical             "dat/sta.dat"
 (
  "STATE"             CHARACTER(2)      omnidex,
  "DESCRIPTION"       STRING(31)        quicktext,
  "STATE_CODE"        CHARACTER(2)      omnidex,
  "REGION"            CHARACTER(2)      omnidex,
  "COUNTRY"           CHARACTER(2)      omnidex,
  "TAX_RATE"          FLOAT             omnidex,
  constraint STATES_STATE_PK primary ("STATE"),
  constraint STATES_COUNTRY_FK foreign ("COUNTRY") references "COUNTRIES"
 )
 in                   "simplegrid.xml";


create table          "GENDERS"
 physical             "dat/gdr.dat"
 (
  "GENDER"            CHARACTER(1)      omnidex,
  "DESCRIPTION"       STRING(31)        quicktext,
  constraint GENDERS_GENDER_PK primary ("GENDER")
 )
 in                   "simplegrid.xml";


create table          "HOUSEHOLDS"
 node "NODE01"
  physical            "dat/households01.dat"
  partition_by        "STATE in ('NY','PR','MA','RI','ME','NH','VT','CT','NJ',
                                 'PA','DE','DC','MD','VA','WV','NC','SC','GA',
                                 'FL','AL','TN','MS','KY','OH') and 
                       ZIP between '01000' and '45999'"
 node "NODE02"
  physical            "dat/households02.dat"
  partition_by        "STATE in ('IN','MI','IA','WI','MN','SD','ND','MT','IL',
                                 'MO','KS','NE','LA','AR','OK','TX','TX','CO',
                                 'WY','ID','UT','AZ','NM','NV','CA','HI','OR',
                                 'WA','AK') and 
                       ZIP between '46000' and '99999'"
 (
  "HOUSEHOLD"         CHARACTER(12)     omnidex,
  "ADDRESS"           CHARACTER(50)     quicktext,
  "CITY"              CHARACTER(28)     quicktext,
  "STATE"             CHARACTER(2)      omnidex,
  "ZIP"               CHARACTER(5)      omnidex,
  "COUNTRY"           CHARACTER(2)      omnidex,
  constraint HOUSEHOLDS_HOUSEHOLD_PK primary ("HOUSEHOLD"),
  constraint HOUSEHOLDS_STATE_FK foreign ("STATE") references "STATES",
  constraint HOUSEHOLDS_COUNTRY_FK foreign ("COUNTRY") references "COUNTRIES"
 )
 in                   "simplegrid.xml";


create table          "INDIVIDUALS"
 node "NODE01"
  physical            "dat/individuals01.dat"
  partition_by        "HOUSEHOLDS.HOUSEHOLD = INDIVIDUALS.HOUSEHOLD" 
 node "NODE02"
  physical            "dat/individuals02.dat"
  partition_by        "HOUSEHOLDS.HOUSEHOLD = INDIVIDUALS.HOUSEHOLD" 
 (
  "INDIVIDUAL"        CHARACTER(12)     omnidex,
  "HOUSEHOLD"         CHARACTER(12)     omnidex,
  "NAME"              CHARACTER(50)     quicktext,
  "GENDER"            CHARACTER(1)      omnidex bitmap,
  "BIRTHDATE"         ANSI DATE         omnidex,
  "PHONE"             CHARACTER(14)     omnidex,
  "EMAIL"             CHARACTER(60)     quicktext,
  constraint INDIVIDUALS_INDIVIDUAL_PK primary ("INDIVIDUAL"),
  constraint INDIVIDUALS_HOUSEHOLD_FK foreign ("HOUSEHOLD") references "HOUSEHOLDS",
  constraint INDIVIDUALS_GENDER_FK foreign ("GENDER") references "GENDERS",
 )
 in                   "simplegrid.xml";
