use sql/simplegrid.sql

connect simplegrid.xml

update indexes;

disconnect
