use sql/simplegrid.sql

connect simplegrid.xml

update indexes;

disconnect


; Update autofilter segments
use sql/segments.sql

