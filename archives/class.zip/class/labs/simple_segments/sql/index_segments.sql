connect simple

; Create a series of index segments, and then reuse them in a final query.

; Create an index segment for Individuals in Denver, CO
create index segment PART_1
 as (select        INDIVIDUALS.$UNIQUEKEY
       from        INDIVIDUALS
       join        HOUSEHOLDS on INDIVIDUALS.HOUSEHOLD = HOUSEHOLDS.HOUSEHOLD
       where       STATE = 'CO' and
                   CITY = 'Denver');

; Create an index segment for Individuals in Phoenix, AZ
create index segment PART_2
 as (select        INDIVIDUALS.$UNIQUEKEY
       from        INDIVIDUALS
       join        HOUSEHOLDS on INDIVIDUALS.HOUSEHOLD = HOUSEHOLDS.HOUSEHOLD
       where       STATE = 'AZ' and
                   CITY = 'Phoenix');

; Create an index segment for Individuals born since 1990
create index segment PART_3
 as (select        INDIVIDUALS.$UNIQUEKEY
       from        INDIVIDUALS
       where       BIRTHDATE >= 'January 1, 1990');

; Incorporate the index segments into a final search
select        INDIVIDUAL,
              BIRTHDATE,
              CITY,
              STATE
  from        INDIVIDUALS
  join        HOUSEHOLDS on INDIVIDUALS.HOUSEHOLD = HOUSEHOLDS.HOUSEHOLD 
  where       INDIVIDUAL in ($segment(PART_1), $segment(PART_2)) and
              INDIVIDUAL = $segment(PART_3);

; Drop the segments
drop segment PART_1;
drop segment PART_2;
drop segment PART_3;

disconnect
