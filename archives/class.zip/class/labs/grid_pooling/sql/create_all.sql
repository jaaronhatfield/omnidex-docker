; To run this script, Omnidex must be running using the odxnet.cfg located 
; in this lab, and the simplegrid.xml must be created using the statements
; in sql/simplegrid.sql

connect simplegrid.xml 

update indexes;

disconnect
