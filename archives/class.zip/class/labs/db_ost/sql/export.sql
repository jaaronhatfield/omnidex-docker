connect to    simple.xml

export        (select        *
                 from        COUNTRIES)
  to          dat/countries.ost
  with        OST INDEXBY=COUNTRY DELETE;

export        (select        *
                 from        STATES)
  to          dat/states.ost
  with        OST INDEXBY=STATE DELETE;

export        (select        *
                 from        GENDERS)
  to          dat/genders.ost
  with        OST INDEXBY=GENDER DELETE;

export        (select        *
                 from        HOUSEHOLDS)
  to          dat/households.ost
  with        OST NULL_INDICATORS=OFF DELETE;

export        (select        *
                 from        INDIVIDUALS)
  to          dat/individuals.ost
  with        OST NULL_INDICATORS=OFF DELETE;

disconnect
