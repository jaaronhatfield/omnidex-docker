create environment
 in                            "temp.xml"
 with                          delete;

create database                "SIMPLE"
 type                          file
 index_directory               "idx"
 in                            "temp.xml";

create table                   "SIMPLE"."COUNTRIES"
 physical                      "D:/class/labs/simple_extract/dat/cnt.dat"
 (
  "COUNTRY"                          character(2)           omnidex,
  "DESCRIPTION"                      string(47)             quicktext,
  "LATITUDE"                         float                  omnidex
   usage "LATITUDE",
  "LONGITUDE"                        float                  omnidex
   usage "LONGITUDE",
  "CAPITAL"                          string(31)             quicktext,
  "CAPITAL_LAT"                      float                  omnidex
   usage "LATITUDE",
  "CAPITAL_LONG"                     float                  omnidex
   usage "LONGITUDE",
  constraint COUNTRIES_COUNTRY_PK primary ("COUNTRY")
 )
 in                            "temp.xml";

create table                   "SIMPLE"."STATES"
 physical                      "D:/class/labs/simple_extract/dat/sta.dat"
 (
  "STATE"                            character(2)           omnidex,
  "DESCRIPTION"                      string(31)             quicktext,
  "STATE_CODE"                       character(2)           omnidex,
  "REGION"                           character(2)           omnidex,
  "COUNTRY"                          character(2)           omnidex,
  "TAX_RATE"                         float                  omnidex,
  constraint STATES_STATE_PK primary ("STATE"),
  constraint STATES_COUNTRY_FK foreign ("COUNTRY") references "COUNTRIES"
 )
 in                            "temp.xml";

create table                   "SIMPLE"."GENDERS"
 physical                      "D:/class/labs/simple_extract/dat/gdr.dat"
 (
  "GENDER"                           character(1)           omnidex,
  "DESCRIPTION"                      string(31)             quicktext,
  constraint GENDERS_GENDER_PK primary ("GENDER")
 )
 in                            "temp.xml";

create table                   "SIMPLE"."HOUSEHOLDS"
 physical                      "D:/class/labs/simple_extract/dat/households*.dat"
 (
  "HOUSEHOLD"                        character(12)          omnidex,
  "ADDRESS"                          character(50)          quicktext,
  "CITY"                             character(28)          quicktext,
  "STATE"                            character(2)           omnidex,
  "ZIP"                              character(5)           omnidex,
  "COUNTRY"                          character(2)           omnidex,
  constraint HOUSEHOLDS_HOUSEHOLD_PK primary ("HOUSEHOLD"),
  constraint HOUSEHOLDS_STATE_FK foreign ("STATE") references "STATES",
  constraint HOUSEHOLDS_COUNTRY_FK foreign ("COUNTRY") references "COUNTRIES"
 )
 in                            "temp.xml";

create table                   "SIMPLE"."INDIVIDUALS"
 physical                      "D:/class/labs/simple_extract/dat/individuals*.dat"
 (
  "INDIVIDUAL"                       character(12)          omnidex,
  "HOUSEHOLD"                        character(12)          omnidex,
  "NAME"                             character(50)          quicktext,
  "GENDER"                           character(1)           omnidex bitmap,
  "BIRTHDATE"                        ansi date              omnidex,
  "PHONE"                            character(14)          omnidex,
  "EMAIL"                            character(60)          quicktext,
  constraint INDIVIDUALS_INDIVIDUAL_PK primary ("INDIVIDUAL"),
  constraint INDIVIDUALS_HOUSEHOLD_FK foreign ("HOUSEHOLD") references
   "HOUSEHOLDS",
  constraint INDIVIDUALS_GENDER_FK foreign ("GENDER") references "GENDERS"
 )
 in                            "temp.xml";

