connect simple;

extract ddl to temp.sql with delete;


