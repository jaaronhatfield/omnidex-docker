attach database                GEO
 from                          geo.xml;

attach table                   "GEO"."AREACODES"
 physical                      "dat/arc.dat"
 (
  "AREACODE"                         character(3),
  "TYPE"                             string(7),
  "TYPE_DESC"                        string(31),
  "ASSIGNABLE"                       character(1),
  "EXPLANATION"                      string(31),
  "RESERVED"                         character(1),
  "ASSIGNED"                         character(1),
  "ASSIGN_DATE"                      ascii date,
  "GEOGRAPHIC"                       character(1),
  "SERVICE"                          string(39),
  "STATES"                           character(10),
  "LOCATION"                         string(31),
  "COUNTRY"                          character(2),
  "AREA_SERVED"                      string(511),
  "IN_SERVICE"                       character(1),
  "IN_SERVICE_DATE"                  ascii date,
  "OVERLAY"                          character(1),
  "OVERLAY_COMPLEX"                  character(20),
  "PARENT"                           character(32),
  "TIME_ZONE1"                       character(1),
  "TIME_ZONE2"                       character(1),
  constraint AREACODES_AREACODE_PK primary ("AREACODE")
 );


select        GEO.COUNTIES.STATE,
              GEO.COUNTIES.COUNTY,
              count(*)
  from        SIMPLE.INDIVIDUALS
  join        SIMPLE.HOUSEHOLDS on SIMPLE.INDIVIDUALS.HOUSEHOLD =
              SIMPLE.HOUSEHOLDS.HOUSEHOLD
  join        GEO.ZIPCODES on SIMPLE.HOUSEHOLDS.ZIP = GEO.ZIPCODES.ZIP
  join        GEO.COUNTIES on GEO.ZIPCODES.STATE = GEO.COUNTIES.STATE and
              GEO.ZIPCODES.COUNTY_CODE = GEO.COUNTIES.COUNTY_CODE
  where       GEO.ZIPCODES.AREACODES in
              (select        AREACODE
                 from        AREACODES
                 where       STATES = 'CO')
  group by    GEO.COUNTIES.STATE,
              GEO.COUNTIES.COUNTY;

explain
