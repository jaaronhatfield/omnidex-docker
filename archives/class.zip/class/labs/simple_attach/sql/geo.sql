create environment           
 in                          "geo.xml"
 with                        delete;


create database              "GEO"
  type                       FILE
  index_directory            "idx"
 in                          "geo.xml";


create table                 "COUNTRIES"
 physical                    "dat/cnt.dat"
 (
  "COUNTRY"                          CHARACTER(2)           omnidex,
  "DESCRIPTION"                      C STRING(47)           quicktext,
  "LATITUDE"                         FLOAT                  omnidex        usage "LATITUDE",
  "LONGITUDE"                        FLOAT                  omnidex        usage "LONGITUDE",
  "CAPITAL"                          C STRING(31)           quicktext,
  "CAPITAL_LAT"                      FLOAT                  omnidex        usage "LATITUDE",
  "CAPITAL_LONG"                     FLOAT                  omnidex        usage "LONGITUDE",
  constraint COUNTRIES_COUNTRY_PK primary ("COUNTRY")
 )
 in                          "geo.xml";


create table                 "REGIONS"
 physical                    "dat/reg.dat"
 (
  "REGION"                           CHARACTER(2)           omnidex,
  "CENSUS_REGION"                    CHARACTER(1)           omnidex,
  "CENSUS_DIVISION"                  CHARACTER(1)           omnidex,
  "DESCRIPTION"                      C STRING(31)           quicktext,
  constraint REGIONS_REGION_PK primary ("REGION")
 )
 in                          "geo.xml";


create table                 "STATES"
 physical                    "dat/sta.dat"
 (
  "STATE"                            CHARACTER(2)           omnidex,
  "DESCRIPTION"                      C STRING(31)           quicktext,
  "STATE_CODE"                       CHARACTER(2)           omnidex,
  "REGION"                           CHARACTER(2)           omnidex,
  "COUNTRY"                          CHARACTER(2)           omnidex,
  "TAX_RATE"                         FLOAT                  omnidex,
  constraint STATES_STATE_PK primary ("STATE"),
  constraint STATES_REGION_FK foreign ("REGION") references "REGIONS",
  constraint STATES_COUNTRY_FK foreign ("COUNTRY") references "COUNTRIES"
 )
 in                          "geo.xml";


create table                 "COUNTIES"
 physical                    "dat/cty.dat"
 (
  "COUNTRY"                          CHARACTER(2)           omnidex,
  "STATE"                            CHARACTER(2)           omnidex,
  "STATE_CODE"                       CHARACTER(2)           omnidex,
  "COUNTY_CODE"                      CHARACTER(3)           omnidex,
  "COUNTY"                           C STRING(31)           quicktext,
  "REGION"                           CHARACTER(2)           omnidex,
  "ACTIVE"                           CHARACTER(1)           omnidex,
  "ELEVATION"                        SMALLINT               omnidex,
  "SQ_MILES"                         INTEGER                omnidex,
  constraint COUNTIES_STATE_PK primary ("STATE","COUNTY_CODE"),
  constraint COUNTIES_STATE_FK foreign ("STATE") references "STATES",
  constraint COUNTIES_REGION_FK foreign ("REGION") references "REGIONS",
  constraint COUNTIES_COUNTRY_FK foreign ("COUNTRY") references "COUNTRIES"
 )
 in                          "geo.xml";


create table                 "ZIPCODES"
 physical                    "dat/zip.dat"
 (
  "ZIP"                              CHARACTER(5)           omnidex,
  "CITY"                             C STRING(25)           omnidex,
  "COUNTY_CODE"                      CHARACTER(3)           omnidex,
  "STATE"                            CHARACTER(2)           omnidex,
  "REGION"                           CHARACTER(2)           omnidex,
  "COUNTRY"                          CHARACTER(2)           omnidex,
  "LATITUDE"                         CHARACTER(9)           omnidex   usage "LATITUDE",
  "LONGITUDE"                        CHARACTER(9)           omnidex   usage "LONGITUDE",
  "TYPE"                             CHARACTER(2)           omnidex,
  "AREACODES"                        CHARACTER(15)          omnidex,
  "TIME_ZONE"                        TINYINT,
  constraint ZIPCODES_ZIP_PK primary ("ZIP"),
  constraint ZIPCODES_STATE_1_FK foreign ("STATE","COUNTY_CODE") references "COUNTIES",
  constraint ZIPCODES_STATE_2_FK foreign ("STATE") references "STATES",
  constraint ZIPCODES_REGION_FK foreign ("REGION") references "REGIONS",
  constraint ZIPCODES_COUNTRY_FK foreign ("COUNTRY") references "COUNTRIES",
  omnidex "LONG_LAT" ("LONGITUDE","LATITUDE")
 )
 in                          "geo.xml";


