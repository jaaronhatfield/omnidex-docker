
; SIMPLE Database
use sql/simple.sql

connect simple.xml

update indexes;

disconnect


; GEO Database
use sql/geo.sql

connect geo.xml

update indexes;

disconnect
