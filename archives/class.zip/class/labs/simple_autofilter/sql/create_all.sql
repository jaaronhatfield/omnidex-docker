use sql/simple.sql

connect simple.xml

update indexes;

disconnect


; Update autofilter segments
use sql/segments.sql

