connect simple

; Create a 'do not contact' data segment containing the INDIVIDUAL primary
; keys for people that should not be contacted.  Note that the option
; oaselect:noautofilter must be used since we cannot allow the autofilter
; to be active while we are regenerating the autofilter itself.

create permanent data segment DO_NOT_CONTACT_INDIVIDUALS
 physical "segments/do_not_contact.txt"
 as (select        INDIVIDUALS.INDIVIDUAL
       from        INDIVIDUALS
       where       INDIVIDUAL in ('002700400161',
                                  '000801147281',
                                  '000404708566',
                                  '000600348661',
                                  '001214451030'))
 with delimited, delete, oaselect:noautofilter;


; The data segment persists when databases are reindexed, but are not as 
; fast as index segments.  The data segment can be referenced in an 
; autofilter, but an index segment would be faster.  Note that the option
; oaselect:noautofilter must be used since we cannot allow the autofilter
; to be active while we are regnerating the autofilter itself.

create permanent index segment DO_NOT_CONTACT_SEGMENT
 physical "segments/do_not_contact.odx"
 as (select        INDIVIDUAL
       from        INDIVIDUALS
       where       INDIVIDUAL in $segment('segments/do_not_contact.txt'))
 with delete, oaselect:noautofilter;

disconnect
