; Record specific allows prejoined queries to perform faster table joins
; at the cost of slower qualifications.  Note that it is rare to use record 
; specific indexes, and more common to simply index the columns desired and 
; prejoin the tables.

select        distinct HOUSEHOLDS.HOUSEHOLD,
              HOUSEHOLDS.ADDRESS,
              HOUSEHOLDS.CITY,
              HOUSEHOLDS.STATE,
              HOUSEHOLDS.ZIP
  from        HOUSEHOLDS
  join        INDIVIDUALS on INDIVIDUALS.HOUSEHOLD = HOUSEHOLDS.HOUSEHOLD
  where       INDIVIDUALS.GENDER = 'M' and
              INDIVIDUALS.BIRTHDATE between 'Jan 1, 1980' and 'Mar 31, 1980';

explain

; Record specific indexes are most frequently used to qualify a parent by 
; multiple children.  It is still more common the simply index the columns 
; desired and prejoin the tables.

select        distinct COUNTRIES.COUNTRY, COUNTRIES.DESCRIPTION
  from        COUNTRIES
  join        HOUSEHOLDS on HOUSEHOLDS.COUNTRY = COUNTRIES.COUNTRY 
  join        INDIVIDUALS on INDIVIDUALS.HOUSEHOLD = HOUSEHOLDS.HOUSEHOLD
  join        STATES on STATES.COUNTRY = COUNTRIES.COUNTRY
  where       INDIVIDUALS.GENDER = 'M' and
              INDIVIDUALS.BIRTHDATE between 'Jan 1, 1980' and 'Mar 31, 1980' and
              STATES.TAX_RATE > 3;

explain

