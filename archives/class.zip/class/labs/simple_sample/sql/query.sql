
; Show base result set without the SAMPLE function
select    I.HOUSEHOLD, 
          I.BIRTHDATE,
          SUBSTRING(I.NAME from 1 for 40)
  from    HOUSEHOLDS H
  join    INDIVIDUALS I 
    on    H.HOUSEHOLD = I.HOUSEHOLD
 where    ((H.STATE = 'CO' and 
            H.CITY = 'Denver') or
           (H.STATE = 'AZ' and 
            H.CITY = 'Phoenix')) and 
          I.BIRTHDATE > 'January 1, 1980';


; Show sample result requesting oldest person per household
select    sample('I.HOUSEHOLD', 'min(I.BIRTHDATE)', 1)
          I.HOUSEHOLD, 
          I.BIRTHDATE,
          SUBSTRING(I.NAME from 1 for 40)
  from    HOUSEHOLDS H
  join    INDIVIDUALS I 
    on    H.HOUSEHOLD = I.HOUSEHOLD
 where    ((H.STATE = 'CO' and 
            H.CITY = 'Denver') or
           (H.STATE = 'AZ' and 
            H.CITY = 'Phoenix')) and 
          I.BIRTHDATE > 'January 1, 1980';
explain

; Show sampling using EVERY function
select    every 3
          I.HOUSEHOLD, 
          I.BIRTHDATE,
          SUBSTRING(I.NAME from 1 for 40)
  from    HOUSEHOLDS H
  join    INDIVIDUALS I 
    on    H.HOUSEHOLD = I.HOUSEHOLD
 where    ((H.STATE = 'CO' and 
            H.CITY = 'Denver') or
           (H.STATE = 'AZ' and 
            H.CITY = 'Phoenix')) and 
          I.BIRTHDATE > 'January 1, 1980';
explain

; Show sampling using RANDOM n function
select    random 10
          I.HOUSEHOLD, 
          I.BIRTHDATE,
          SUBSTRING(I.NAME from 1 for 40)
  from    HOUSEHOLDS H
  join    INDIVIDUALS I 
    on    H.HOUSEHOLD = I.HOUSEHOLD
 where    ((H.STATE = 'CO' and 
            H.CITY = 'Denver') or
           (H.STATE = 'AZ' and 
            H.CITY = 'Phoenix')) and 
          I.BIRTHDATE > 'January 1, 1980';
explain


; Show sampling using RANDOM n% function
select    random 10%
          I.HOUSEHOLD, 
          I.BIRTHDATE,
          SUBSTRING(I.NAME from 1 for 40)
  from    HOUSEHOLDS H
  join    INDIVIDUALS I 
    on    H.HOUSEHOLD = I.HOUSEHOLD
 where    ((H.STATE = 'CO' and 
            H.CITY = 'Denver') or
           (H.STATE = 'AZ' and 
            H.CITY = 'Phoenix')) and 
          I.BIRTHDATE > 'January 1, 1980';
explain

