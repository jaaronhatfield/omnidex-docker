connect to    simple.xml

export        (select        *
                 from        "COUNTRIES")
  to          "dat/cnt.dat"
  with        DELETE;
export        (select        *
                 from        "STATES")
  to          "dat/sta.dat"
  with        DELETE;
export        (select        *
                 from        "GENDERS")
  to          "dat/gdr.dat"
  with        DELETE;
export        (select        *
                 from        "HOUSEHOLDS")
  to          "dat/households.dat"
  with        DELETE;
export        (select        *
                 from        "INDIVIDUALS")
  to          "dat/individuals.dat"
  with        DELETE;

disconnect
