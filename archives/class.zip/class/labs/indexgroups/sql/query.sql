; The first index group combines the ADDRESS, CITY, STATE and ZIP columns
; into one group.  A search against any of those columns will automatically
; search all of the columns.

select        ADDRESS,
              CITY,
              STATE,
              ZIP
  from        HOUSEHOLDS
  where       ADDRESS = 'Water St, Denver CO';


; This feature can be of great benefit, but be careful.  In this search,
; one would think that the address is so specific that only a correct match
; would be found.  Since columns can have overlapping data values, this is not
; always true;

select        ADDRESS,
              CITY,
              STATE,
              ZIP
  from        HOUSEHOLDS
  where       ADDRESS = '5527 BOLLING CT, WASHINGTON, DC';

select        ADDRESS,
              CITY,
              STATE,
              ZIP
  from        HOUSEHOLDS
  where       ADDRESS = '78703 AUSTIN RD, WINDSOR TX';


; This feature also means that the indexes cannot be used for other
; optimizations, such as aggregations and joins.  Because of that,
; sometimes it is warranted to index the data twice, once by itself and
; once in an index group.  An expression-based column can be used to
; reference the index group.

select        INDIVIDUAL,
              substring(NAME from 1 for 24) FULL_NAME,
              substring(EMAIL from 1 for 20) E_MAIL,
              PHONE
  from        INDIVIDUALS
  where       GENERAL_SEARCH in ('000900574785', 'Anna Williams',
               'csimmons@bgca.org', '303 623 1163');


; The redundant indexing allows the underlying fields to still be referenced
; in normal SQL statements without using the index group

select        count(*)
  from        INDIVIDUALS
  where       PHONE = ' ' and
              EMAIL = ' ';



; Index groups can even span multiple tables if they have been indexed
; a prejoined parent and children.

select        HOUSEHOLDS.HOUSEHOLD,
              substring(TRIM(HOUSEHOLDS.ADDRESS) || ', ' ||
              TRIM(HOUSEHOLDS.CITY) || ', ' ||
              HOUSEHOLDS.STATE || ' ' || 
              TRIM(HOUSEHOLDS.ZIP) from 1 for 48) FULL_ADDRESS,
              INDIVIDUALS.INDIVIDUAL
  from        HOUSEHOLDS
  join        INDIVIDUALS on HOUSEHOLDS.HOUSEHOLD = INDIVIDUALS.HOUSEHOLD
  where       MASTER_SEARCH in ('015088460638', '000804703395');

