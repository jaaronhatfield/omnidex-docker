create environment           
 in                          "simple.xml"
 with                        delete;


create database              "SIMPLE"
  type                       FILE
  index_directory            "idx"
 in                          "simple.xml";


create table                 "COUNTRIES"
 physical                    "dat/cnt.dat"
 (
  "COUNTRY"                  CHARACTER(2)      omnidex,
  "DESCRIPTION"              STRING(47)        quicktext,
  "LATITUDE"                 FLOAT             omnidex      usage "LATITUDE",
  "LONGITUDE"                FLOAT             omnidex      usage "LONGITUDE",
  "CAPITAL"                  STRING(31)        quicktext,
  "CAPITAL_LAT"              FLOAT             omnidex      usage "LATITUDE",
  "CAPITAL_LONG"             FLOAT             omnidex      usage "LONGITUDE",
  constraint COUNTRIES_COUNTRY_PK primary ("COUNTRY")
 )
 in                          "simple.xml";


create table                 "STATES"
 physical                    "dat/sta.dat"
 (
  "STATE"                    CHARACTER(2)      omnidex,
  "DESCRIPTION"              STRING(31)        quicktext,
  "STATE_CODE"               CHARACTER(2)      omnidex,
  "REGION"                   CHARACTER(2)      omnidex,
  "COUNTRY"                  CHARACTER(2)      omnidex,
  "TAX_RATE"                 FLOAT             omnidex,
  constraint STATES_STATE_PK primary ("STATE"),
  constraint STATES_COUNTRY_FK foreign ("COUNTRY") references "COUNTRIES"
 )
 in                          "simple.xml";


create table                 "GENDERS"
 physical                    "dat/gdr.dat"
 (
  "GENDER"                   CHARACTER(1)      omnidex,
  "DESCRIPTION"              STRING(31)        quicktext,
  constraint GENDERS_GENDER_PK primary ("GENDER")
 )
 in                          "simple.xml";


create table                 "HOUSEHOLDS"
 physical                    "dat/households*.dat"
 (
  "HOUSEHOLD"                CHARACTER(12)     omnidex,
  "ADDRESS"                  CHARACTER(50)     quicktext,
  "CITY"                     CHARACTER(28)     quicktext,
  "STATE"                    CHARACTER(2)      quicktext,
  "ZIP"                      CHARACTER(5)      quicktext,
  "COUNTRY"                  CHARACTER(2)      quicktext,
  "MASTER_SEARCH"            CHARACTER(60)     quicktext
    as "' '",
  constraint  HOUSEHOLDS_HOUSEHOLD_PK primary ("HOUSEHOLD"),
  constraint  HOUSEHOLDS_STATE_FK foreign ("STATE") references "STATES",
  constraint  HOUSEHOLDS_COUNTRY_FK foreign ("COUNTRY") references "COUNTRIES",
  omnidex     MASTER_SEARCH_HOUSEHOLD ("HOUSEHOLD"),
  index group ADDRESS_LINES ("ADDRESS", 
                             "CITY", 
                             "STATE", 
                             "ZIP"),
 )
 in                          "simple.xml";


create table                 "INDIVIDUALS"
 physical                    "dat/individuals*.dat"
 (
  "INDIVIDUAL"               CHARACTER(12)     omnidex,
  "HOUSEHOLD"                CHARACTER(12)     omnidex,
  "NAME"                     CHARACTER(50)     quicktext,
  "GENDER"                   CHARACTER(1)      omnidex,
  "BIRTHDATE"                ANSI DATE         omnidex,
  "PHONE"                    CHARACTER(14)     omnidex,
  "EMAIL"                    CHARACTER(60)     quicktext,
  "GENERAL_SEARCH"           CHARACTER(60)     quicktext     
    as "' '",
  constraint  INDIVIDUALS_INDIVIDUAL_PK primary ("INDIVIDUAL"),
  constraint  INDIVIDUALS_HOUSEHOLD_FK foreign ("HOUSEHOLD") references "HOUSEHOLDS" prejoin,
  constraint  INDIVIDUALS_GENDER_FK foreign ("GENDER") references "GENDERS",
  quicktext   GENERAL_GROUP_INDIVIDUAL ("INDIVIDUAL"),
  quicktext   GENERAL_GROUP_NAME ("NAME"),
  quicktext   GENERAL_GROUP_PHONE ("PHONE"),
  quicktext   GENERAL_GROUP_EMAIL ("EMAIL"),
  custom      MASTER_SEARCH_INDIVIDUAL ("INDIVIDUAL") record_complex prejoin "HOUSEHOLDS",
  index group GENERAL_SEARCH ("GENERAL_SEARCH",
                              "GENERAL_GROUP_INDIVIDUAL",
                              "GENERAL_GROUP_NAME", 
                              "GENERAL_GROUP_PHONE",
                              "GENERAL_GROUP_EMAIL") 
 )
 in                          "simple.xml";


create index group          "MASTER_SEARCH"
 (
  "HOUSEHOLDS"."MASTER_SEARCH",
  "HOUSEHOLDS"."MASTER_SEARCH_HOUSEHOLD",
  "INDIVIDUALS"."MASTER_SEARCH_INDIVIDUAL"
 )
 in                          "simple.xml";

