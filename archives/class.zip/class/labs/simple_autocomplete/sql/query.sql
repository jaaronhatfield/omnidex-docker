set pagelength 0

; Begin with an ActiveCounts query that does not require AutoComplete
select        GENDER,
              count(*)
  from        INDIVIDUALS
  group by    GENDER;

explain

; Now do an AutoComplete search on names for that gender.  AutoComplete 
; is used once they have typed in two or three characters.  The 
; OPT=DISTINCT_KEY option is required on QuickText indexes.

select        NAME,
              count(*)
  from        INDIVIDUALS
  where       GENDER = 'M' and
              NAME = 'WIL*'
  group by    NAME
  with        opt=distinct_key;

explain;

; There are two approaches to AutoComplete.  The most efficient approach 
; would be to hold the result set from the previous query in the client
; application's memory, and filter rows as more characters are typed in.
; An alternate approach is to resubmit a query for each successive 
; character, but that is generally not recommended due to performance.

select        NAME,
              count(*)
  from        INDIVIDUALS
  where       GENDER = 'M' and
              NAME = 'WILL*'
  group by    NAME
  with        opt=distinct_key;

explain;

