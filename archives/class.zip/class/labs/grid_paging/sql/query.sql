
; Select the first page of rows
select    top 10 skip 0
          H.HOUSEHOLD, 
          I.NAME
  from    HOUSEHOLDS H
  join    INDIVIDUALS I 
    on    H.HOUSEHOLD = I.HOUSEHOLD
 where    I.BIRTHDATE between 'January 1, 1980' and 'June 30, 1980';
explain

; Select the second page of rows
select    top 10 skip 10
          H.HOUSEHOLD, 
          I.NAME
  from    HOUSEHOLDS H
  join    INDIVIDUALS I 
    on    H.HOUSEHOLD = I.HOUSEHOLD
 where    I.BIRTHDATE between 'January 1, 1980' and 'June 30, 1980';
explain

; Select the second page of rows
select    top 10 skip 20
          H.HOUSEHOLD, 
          I.NAME
  from    HOUSEHOLDS H
  join    INDIVIDUALS I 
    on    H.HOUSEHOLD = I.HOUSEHOLD
 where    I.BIRTHDATE between 'January 1, 1980' and 'June 30, 1980';
explain

