connect to omnidex

export        (select        $SQL_STATEMENT
                 from        $PAST_STATEMENTS
                 where       $CONNECTIONID in
                             (select        distinct
                                            $PAST_CONNECTIONS.$CONNECTIONID
                                from        $PAST_CONNECTIONS
                                join        $ENVIRONMENTS on
                                            $PAST_CONNECTIONS.$ENVIRONMENTID
                                            = $ENVIRONMENTS.$ENVIRONMENTID
                                where       $ENVIRONMENTS.$FILENAME like
                                            '%simple.xml%'))
  to          "d:/class/labs/qa/sql/test4"
  with        delimited, delete;

rename d:/class/labs/simple_qa/sql/test4.tdf d:/class/labs/simple_qa/sql/test4


