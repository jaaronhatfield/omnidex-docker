Cheat sheet for using the DISC internal QA system
-------------------------------------------------

Subdirectories that must be present to run the qa system:

  sql
  log
  res
  dif


Directives that can be used in a test series:

  ; <COMMON>
  ; <SECTION>
  ; <TEST>


To run a test series:

  qa test1


To run more than one test series:

  qa test1 test2 test3


To recreate a result file for a test series:

  qa -resgen test1



