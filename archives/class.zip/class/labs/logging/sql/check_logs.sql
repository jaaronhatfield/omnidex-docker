connect to omnidex

update statistics;

; This statement shows the first 10 statements from the logs
select        top 10 
              $SQL_STATEMENT
  from        $PAST_STATEMENTS;

; This statement shows the 10 longest-running statements from today
select        top 10 
              substring($SQL_STATEMENT from 1 for 50) SQL_STATEMENT,
              $RETRIEVED RECORDS,
              cast($ELAPSED as character(12)) SECONDS
  from        $PAST_STATEMENTS
  where       $compare_dates($START_TIME, current_date) < 1
  order by    $ELAPSED desc;

; This statement shows the 10 longest-running statements from today,
; including showing the environment file name.
select        top 10 
              trim(substring($ENVIRONMENTS.$FILENAME from 1 for 60)) || 
                ' (' || trim($ENVIRONMENTS.$ROLE) || ')' FILENAME,
              substring($PAST_STATEMENTS.$SQL_STATEMENT from 1 for 50)
                SQL_STATEMENT,
              $PAST_STATEMENTS.$RETRIEVED RECORDS,
              cast($PAST_STATEMENTS.$ELAPSED as character(12)) SECONDS
  from        $PAST_STATEMENTS
  join        $PAST_CONNECTIONS on $PAST_STATEMENTS.$CONNECTIONID =
              $PAST_CONNECTIONS.$CONNECTIONID
  join        $ENVIRONMENTS on $PAST_CONNECTIONS.$ENVIRONMENTID =
              $ENVIRONMENTS.$ENVIRONMENTID
  where       $compare_dates($PAST_STATEMENTS.$START_TIME, current_date) < 1
  order by    $PAST_STATEMENTS.$ELAPSED desc;

; This statement shows all statements that return an error code, other than 
; the END OF DATA error code.
select        substring($PAST_STATEMENTS.$SQL_STATEMENT from 1 for 50) 
               SQL_STATEMENT,
              $PAST_STATEMENTS.$ERROR ERRCODE, 
              $MESSAGES.$MESSAGE MESSAGE
  from        $PAST_STATEMENTS
  left join   $MESSAGES on $PAST_STATEMENTS.$ERROR = $MESSAGES.$ERROR
  where       $PAST_STATEMENTS.$ERROR not in (0, 11032);


disconnect


