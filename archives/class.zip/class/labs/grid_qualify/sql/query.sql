set qualify_counts preintersect

; The following queries are variations or subsets of the following SQL query
;
; select    I.GENDER, count(*)
;   from    HOUSEHOLDS H
;   join    INDIVIDUALS I
;     on    H.HOUSEHOLD = I.HOUSEHOLD
;  where    ((H.STATE = 'CO' and
;             H.CITY = 'Denver') or
;            (H.STATE = 'AZ' and
;             H.CITY = 'Phoenix')) and
;           I.BIRTHDATE > 'January 1, 1980'
; group by  I.GENDER;
;

; Single-table qualifications
qualify HOUSEHOLDS where CITY = 'Denver';
qualify HOUSEHOLDS where and STATE = 'CO';

select        HOUSEHOLDS.HOUSEHOLD,
              HOUSEHOLDS.CITY,
              HOUSEHOLDS.STATE
  from        HOUSEHOLDS
  with        odxid;

; Single-table qualifications with index segments for parentheses

qualify HOUSEHOLDS where CITY = 'Denver';
qualify HOUSEHOLDS where and STATE = 'CO';

create index segment X with delete;

qualify HOUSEHOLDS where CITY = 'Phoenix';
qualify HOUSEHOLDS where and STATE = 'AZ';

qualify HOUSEHOLDS where or HOUSEHOLD = 'segment(x)';

select        HOUSEHOLDS.HOUSEHOLD,
              HOUSEHOLDS.CITY,
              HOUSEHOLDS.STATE
  from        HOUSEHOLDS
  with        odxid;

; Multi-table qualifications
qualify HOUSEHOLDS where CITY = 'Denver';
qualify HOUSEHOLDS where and STATE = 'CO';

create index segment X with delete;

qualify HOUSEHOLDS where CITY = 'Phoenix';
qualify HOUSEHOLDS where and STATE = 'AZ';

qualify HOUSEHOLDS where or HOUSEHOLD = 'segment(x)';

join HOUSEHOLDS using HOUSEHOLD to INDIVIDUALS using HOUSEHOLD;

qualify INDIVIDUALS where and BIRTHDATE > ' "January 1, 1980" ';

select        I.GENDER,
              count(*)
  from        HOUSEHOLDS H
  join        INDIVIDUALS I on H.HOUSEHOLD = I.HOUSEHOLD
  group by    I.GENDER
  with        odxid;



