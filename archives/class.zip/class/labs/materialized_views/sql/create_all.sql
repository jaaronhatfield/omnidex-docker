use sql/simple.sql

connect simple.xml

update indexes;

; Update statistics to further improve performance optimization 
update statistics;

; Export the SIMPLE_VIEW table
use sql/export_view.sql

disconnect


use sql/simple_view.sql

connect simple_view.xml

update indexes;

; Update statistics to further improve performance optimization 
update statistics;

disconnect
