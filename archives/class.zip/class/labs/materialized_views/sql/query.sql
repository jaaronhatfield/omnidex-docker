connect to simple_view;

; Queries that group a fact table based on dimension tables can 
; cause a lot of re-aggregation after the table joins.  In this example
; INDIVIDUALS must be joined to HOUSEHOLDS in order to further join 
; to STATES.  While there are very few STATES, there are many HOUSEHOLDS.  
; This requires a lot of processing overhead.

select        STATES.DESCRIPTION,
              GENDERS.DESCRIPTION,
              count(*)
  from        INDIVIDUALS 
  join        HOUSEHOLDS on INDIVIDUALS.HOUSEHOLD = HOUSEHOLDS.HOUSEHOLD
  join        STATES on HOUSEHOLDS.STATE = STATES.STATE
  join        GENDERS on INDIVIDUALS.GENDER = GENDERS.GENDER
  where       REGION in ('MT','PC')
  group by    STATES.DESCRIPTION,
              GENDERS.DESCRIPTION;

explain;


; Rewriting the query to use a denormalized, materialized view can allow 
; more aggregation to occur before the table joins.  The STATE codes
; were brought directly into the materialized view.  This allows the
; aggregations in the view to produce very few rows that then need 
; joining into the STATES and GENDERS tables.

select        STATES.DESCRIPTION,
              GENDERS.DESCRIPTION,
              count(*)
  from        SIMPLE_VIEW 
  join        STATES on SIMPLE_VIEW.STATE = STATES.STATE
  join        GENDERS on SIMPLE_VIEW.GENDER = GENDERS.GENDER
  where       SIMPLE_VIEW.REGION in ('MT','PC')
  group by    STATES.DESCRIPTION,
              GENDERS.DESCRIPTION;

explain;

disconnect

