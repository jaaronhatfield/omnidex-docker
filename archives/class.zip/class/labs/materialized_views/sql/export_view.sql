; Create SIMPLE_VIEW table.  This should be a materialized view, constructed
; using a SQL statement that joins tables, converts expressions into columns,
; and filters data.

; Note that this statement uses  an especially large HDC_THRESHOLD so that
; the Hashed Data Cache can be used even when the tables are quite large.

export        
  (
  select        INDIVIDUALS.INDIVIDUAL,
                HOUSEHOLDS.HOUSEHOLD,
                HOUSEHOLDS.ADDRESS,
                HOUSEHOLDS.CITY,
                HOUSEHOLDS.STATE,
                STATES.REGION,
                STATES.TAX_RATE,
                HOUSEHOLDS.ZIP,
                HOUSEHOLDS.COUNTRY,
                INDIVIDUALS.NAME,
                INDIVIDUALS.GENDER,
                INDIVIDUALS.BIRTHDATE,
                cast($compare_dates(INDIVIDUALS.BIRTHDATE, current_date, 'YY') 
                  as integer) AGE,
                cast(case
                  when $compare_dates(INDIVIDUALS.BIRTHDATE, current_date, 'YY') 
                    between 0 and 17 then '0-17'
                  when $compare_dates(INDIVIDUALS.BIRTHDATE, current_date, 'YY') 
                    between 18 and 29 then '18-29'
                  when $compare_dates(INDIVIDUALS.BIRTHDATE, current_date, 'YY') 
                    between 30 and 39 then '30-39'
                  when $compare_dates(INDIVIDUALS.BIRTHDATE, current_date, 'YY') 
                    between 40 and 49 then '40-49'
                  when $compare_dates(INDIVIDUALS.BIRTHDATE, current_date, 'YY') 
                    between 50 and 59 then '50-59'
                  else '60+'
                end as character(10)) AGE_GROUP,
                INDIVIDUALS.PHONE,
                cast(substring(INDIVIDUALS.PHONE from 2 for 3) 
                  as character(3)) PHONE_AREACODE,
                cast(substring(INDIVIDUALS.PHONE from 7 for 3) 
                  as character(3)) PHONE_PREFIX,
                cast(substring(INDIVIDUALS.PHONE from 11 for 4) 
                  as character(4)) PHONE_SUFFIX,
                INDIVIDUALS.EMAIL,
                cast(case
                  when position('@' in INDIVIDUALS.EMAIL) > 0 then 
                    substring(INDIVIDUALS.EMAIL from 1 for 
                      position('@' in INDIVIDUALS.EMAIL) - 1)
                  else ''
                end as character(60)) EMAIL_MAILBOX,
                cast(case
                  when position('@' in INDIVIDUALS.EMAIL) > 0 then 
                    substring(INDIVIDUALS.EMAIL 
                      from position('@' in INDIVIDUALS.EMAIL) + 1)
                  else ''
                end as character(60)) EMAIL_DOMAIN
    from        INDIVIDUALS
    join        HOUSEHOLDS on INDIVIDUALS.HOUSEHOLD =
                HOUSEHOLDS.HOUSEHOLD
    join        STATES on HOUSEHOLDS.STATE = STATES.STATE
    join        COUNTRIES on STATES.COUNTRY = COUNTRIES.COUNTRY
    join        GENDERS on INDIVIDUALS.GENDER = GENDERS.GENDER
    where       HOUSEHOLDS.COUNTRY = 'US' and 
                INDIVIDUALS.BIRTHDATE <= 'December 31, 1999'
  )
  to          dat/simple_view.dat
  with        delete, data_cache=1024;


