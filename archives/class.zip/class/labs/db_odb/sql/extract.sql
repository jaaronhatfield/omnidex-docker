extract       DDL
  for         ODBC
  to          "simple.sql"
  with        USER="simple"
              PASSWORD="simple"
              FILEDSN="dat/simple.dsn"
              DATABASE="simple"
              INDEX_DIRECTORY="idx"
