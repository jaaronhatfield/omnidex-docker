use sql/books.sql

connect books.xml

; Load the Offset Indexes for delimited files
load ofx;

update indexes;

disconnect
