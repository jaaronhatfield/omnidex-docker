create environment             
 in                            "books.xml"
 with                          delete;

create database                "TEXT"
 type                          file
 index_directory               "idx"
 in                            "books.xml";

create table                   "BOOKS"
 options                       "delimited record='\r\n'"
 physical                      "dat/books.txt"
 (
  "DOC_ID"                           character(8)   omnidex,
  "CLASS"                            character(4)   omnidex,
  "FICTION"                          character(1)   omnidex,
  "LANGUAGE"                         character(32)  omnidex,
  "TITLE"                            string(80)     fulltext,
  "AUTHOR"                           string(80)     fulltext   usage "NAME",
  "SOURCE"                           string(80)     quicktext,
  "FILENAME"                         string(255)    quicktext,
  "CONTENT"                          string(1MB)    fulltext   usage "TEXT"
   as "$retrieve_file(FILENAME, 'STRING(1MB)')",
  constraint DOC_ID_PK primary ("DOC_ID"),
 )
 in                            "books.xml";
