; Show most relevant titles that have the word "place" within 25 words
; of the word "home"

select        $score,
              TITLE,
              $context
  from        BOOKS
  where       $contains(CONTENT, '(place near(25) home)')
  order by    $score desc;


; Show most relevant titles that have the misspelled word "Missisipi",
; as well as the correct word "Mississippi"

select        $score,
              TITLE,
              $context
  from        BOOKS
  where       $contains(CONTENT, 'Missisipi', 'misspellings')
  order by    $score desc;
