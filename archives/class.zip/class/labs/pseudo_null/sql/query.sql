
; Raw data files do not contain null indicators.  Omnidex will treat empty
; strings and binary 0's as nulls.

select        count(*)
  from        INDIVIDUALS
  where       EMAIL is null;

select        count(*)
  from        INDIVIDUALS
  where       PHONE is not null;

select        count(*)
  from        INDIVIDUALS
  where       EMAIL is null and
              PHONE is not null;


; Omnidex will allow aggregations results to show null results.  Null results
; are any results where containing an empty string or a binary 0.

select        COUNTRY,
              REGION,
              STATE_CODE
  from        STATES
  where       COUNTRY in ('US', 'CN') and
              REGION in ('CN', 'AF', 'NE')
  group by    COUNTRY,
              REGION,
              STATE_CODE;



