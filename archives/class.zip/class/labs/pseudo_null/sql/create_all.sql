use sql/simple.sql

connect simple.xml

update indexes;

disconnect
