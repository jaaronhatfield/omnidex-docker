; ActiveCounts will allow a series of optimized statements which
; display counts to the user as they apply criteria.

set pagelength 0

; Step 1: Display all of the States and their respective counts:
select        STATE,
              count(*)
  from        INDIVIDUALS
  join        HOUSEHOLDS on INDIVIDUALS.HOUSEHOLD = HOUSEHOLDS.HOUSEHOLD
  group by    STATE;

explain

; Step 2: Display all cities for the selected state:
select        CITY,
              count(*)
  from        INDIVIDUALS
  join        HOUSEHOLDS on INDIVIDUALS.HOUSEHOLD = HOUSEHOLDS.HOUSEHOLD
  where       STATE = 'CO'
  group by    CITY;

explain

; Step 3; Display all zipcodes for the selected city and state:
select        ZIP,
              count(*)
  from        INDIVIDUALS
  join        HOUSEHOLDS on INDIVIDUALS.HOUSEHOLD = HOUSEHOLDS.HOUSEHOLD
  where       STATE = 'CO' and
              CITY = 'DENVER'
  group by    ZIP;

explain

; Step 4; Display the gender of all individuals for the selected city, 
;         state and zip:
select        GENDER,
              count(*)
  from        INDIVIDUALS
  join        HOUSEHOLDS on INDIVIDUALS.HOUSEHOLD = HOUSEHOLDS.HOUSEHOLD
  where       STATE = 'CO' and
              CITY = 'DENVER' and
              ZIP in ('80209', '80210', '80211', '80212', '80216')
  group by    GENDER;

explain

; Step 5; Display the age of all individuals for the selected city, state, 
;         zip and gender:
select        AGE,
              count(*)
  from        INDIVIDUALS
  join        HOUSEHOLDS on INDIVIDUALS.HOUSEHOLD = HOUSEHOLDS.HOUSEHOLD
  where       STATE = 'CO' and
              CITY = 'DENVER' and
              ZIP in ('80209', '80210', '80211', '80212', '80216') and
              GENDER = 'F'
  group by    AGE;

explain

